/* eslint-disable react/jsx-props-no-spreading */
import React from "react";
import { withRouter } from "react-router-dom";
import PropTypes from "prop-types";
import _ from "lodash";
// Layout
import Layout from "../../layouts/index";
// Components
import HomeDocumentForm from "./HomePageForm/index";
import TabsComponent from "../../components/Tabs";
import FileUpload from "../../components/FileUpload";

// Utils
import { SUPPORTED_FILE_TYPES } from "../../utils";

import { EXCEL_SCHEMA } from "../../utils/templates";

import XLSX from "xlsx";
import Button from "@material-ui/core/Button";
import AlertsComponent from "../../components/Alert";

const propTypes = {
  location: PropTypes.shape({
    pathname: PropTypes.string,
    search: PropTypes.string,
  }).isRequired,
  history: PropTypes.shape({ push: PropTypes.func }).isRequired,
};

const HomePage = (props) => {
  const pageName = "Home";
  const { location, history } = props;
  const FILE_LIMIT = 1;
  const [files, setFiles] = React.useState([]);
  const [isValidFile, setIsValidFile] = React.useState(true);

  // Function handles the file selection and removal on click delete button from selected file list
  function handleFileChange(fileList, index = -1, removeFlag = false) {
    if (removeFlag) {// handles deleting file
      setFiles([]);
      handleFile([]);
    } else {// handles files selection
      setFiles(fileList);
      handleFile(fileList);
    }
  }

  const handleFile = (filesL) => {
    /* Boilerplate to set up FileReader */
    const reader = new FileReader();
    const rABS = !!reader.readAsBinaryString;

    reader.onload = (e) => {
      /* Parse data */
      const bstr = e.target.result;
      const wb = XLSX.read(bstr, {
        type: rABS ? "binary" : "array",
        bookVBA: true,
        sheetRows: 1,
      });
      /* Get first worksheet */
      const wsname = wb.SheetNames[0];
      const ws = wb.Sheets[wsname];

      const FILE_SCHEMA = XLSX.utils.sheet_to_json(ws, {
        header: 1,
      });

      setIsValidFile(_.isEqual(EXCEL_SCHEMA.SCHEMA, FILE_SCHEMA[0]));

      if (!_.isEqual(EXCEL_SCHEMA.SCHEMA, FILE_SCHEMA[0])) {
        setFiles([]);
        handleFile([]);
      }
    };

    if (filesL && filesL.length > 0) {
      if (rABS) {
        reader.readAsBinaryString(filesL[0]["file"]);
      } else {
        reader.readAsArrayBuffer(filesL[0]["file"]);
      }
    }
  };

  const tabList = [
    {
      title: "PDF UPLOAD",
      component: <HomeDocumentForm {...props} />,
      disabled: false,
    },
    {
      title: "EXCEL UPLOAD",
      component: (
        <>
          <FileUpload
            handleFileChange={handleFileChange}
            supportedFileTypes={SUPPORTED_FILE_TYPES.EXCEL.MIME_TYPE}
            fileLimit={FILE_LIMIT}
            fileList={files} // prop of selected files list, to preview files selected
            showAlerts={isValidFile} // prop when upload file is invalid alert is not shown
          />
          <Button variant="contained" color="primary">
            SAVE
          </Button>
        </>
      ),
      disabled: false,
    },
  ];

  return (
    <Layout page={pageName} location={location} history={history}>
      {!isValidFile && (
        <AlertsComponent
          type={isValidFile ? "success" : "error"}
          message={
            isValidFile
              ? "Uploaded file is valid"
              : "Uploaded file is not valid"
          }
        />
      )}
      <TabsComponent tabList={tabList} />
    </Layout>
  );
};

HomePage.propTypes = propTypes;
export default withRouter(HomePage);
