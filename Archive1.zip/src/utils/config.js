const oktaAuthConfig = {
  // Note: If your app is configured to use the Implicit Flow
  // instead of the Authorization Code with Proof of Code Key Exchange (PKCE)
  // you will need to add `pkce: false`
  issuer: 'https://dev-7974290.okta.com/oauth2/default',
  clientId: '0oa3fwe8hkCAmmHOr5d6',
  redirectUri: `${window.location.origin}/home`,
  scopes: ['openid', 'profile', 'email'],
  onAuthRequired: true,
  scopeId: "okta.users.read",

};

const oktaSignInConfig = {
  baseUrl: 'https://dev-7974290.okta.com',
  clientId: '0oa3fwe8hkCAmmHOr5d6',
  redirectUri: `${window.location.origin}/home`,
  authParams: {
    // If your app is configured to use the Implicit Flow
    // instead of the Authorization Code with Proof of Code Key Exchange (PKCE)
    // you will need to uncomment the below line
    // pkce: false
  },
  scopes: ['openid', 'profile', 'email'],
  scopeId: "okta.users.read",
  onAuthRequired: true,
  pkce:true
};


export { oktaAuthConfig, oktaSignInConfig };
