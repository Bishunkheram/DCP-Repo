/* eslint-disable react/jsx-props-no-spreading */
import React, { useState } from 'react';

import Dropzone from 'react-dropzone';
import './UploadFile.css';

const UploadFile = (onSelectFiles) => {
  const [fileNames, setFileNames] = useState([]);

  const handleDrop = (acceptedFiles) => {
    setFileNames(acceptedFiles.map((file) => file.name));
    onSelectFiles(acceptedFiles);
  };

  return (
    <div className="text-center">
      <Dropzone onDrop={handleDrop} maxFiles={1} types={['pdf, xlsx, csv']}>
        {({ getRootProps, getInputProps }) => (
          <div {...getRootProps({ className: 'dropzone' })}>
            <input {...getInputProps()} accept="application/pdf" />
            <i className="fa fa-arrow-circle-o-up upload_icon" aria-hidden="true" />
            <br />
            <div style={{ color: '#949495', marginTop: '10px' }}>Drop file here for browse</div>
            <div>
              <ul className="filename">
                {fileNames.map((fileName) => (
                  <li key={fileName}>{fileName}</li>
                ))}
              </ul>
            </div>
          </div>
        )}
      </Dropzone>
    </div>
  );
};

export default UploadFile;
