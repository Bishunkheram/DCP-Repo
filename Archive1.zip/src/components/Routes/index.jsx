/* eslint-disable react/jsx-props-no-spreading */
import React from 'react';
import { Route, useHistory, Switch } from 'react-router-dom';
import { Security, SecureRoute } from '@okta/okta-react';
import { OktaAuth } from '@okta/okta-auth-js';
import HomePage from '../../pages/HomePage';
import Discover from '../../pages/Discover';
import { oktaAuthConfig, oktaSignInConfig } from '../../utils/config';
import Login from '../../pages/Login';
import Visualize from '../../pages/Visualize';

const oktaAuthClient = new OktaAuth(oktaAuthConfig);

const AppWithRouterAccess = () => {
  const history = useHistory();

  const customAuthHandler = () => {
    history.push('/login');
  };

  return (
    <Security onAuthRequired={customAuthHandler} oktaAuth={oktaAuthClient}>
      <Switch>
        <Route exact path="/" render={() => <Login config={oktaSignInConfig} />} />
        <Route exact path="/login" render={() => <Login config={oktaSignInConfig} />} />
        <SecureRoute exact path="/home" render={(props) => <HomePage {...props} />} />
        <SecureRoute exact path="/discover" render={(props) => <Discover {...props} />} />
        <SecureRoute exact path="/visualize" render={(props) => <Visualize {...props} />} />
      </Switch>
    </Security>
  );
};
export default AppWithRouterAccess;
