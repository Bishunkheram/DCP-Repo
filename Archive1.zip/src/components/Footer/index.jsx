import React from 'react';
import './Footer.css';

const Footer = () => <>Footer</>;

export default Footer;
