/* eslint-disable react/prop-types */
import React from 'react';

const SearchBox = ({ searchString, handleChange, searchFilter }) => (
  <div className="input-group search">
    <input
      type="text"
      className="form-control input-sm"
      placeholder="Enter keywords "
      name="searchString"
      id="searchString"
      value={searchString}
      onChange={handleChange}
    />
    <div className="input-group-btn">
      <button className="btn btn-default btn-sm" type="submit" onClick={searchFilter}>
        <i className="glyphicon glyphicon-search" />
      </button>
    </div>
  </div>
);

export default SearchBox;
