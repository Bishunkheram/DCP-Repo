import React, { useState } from "react";
import PropTypes from "prop-types";
import * as d3Collection from "d3-collection";
import listJsonData from "../../data/documentListJsonData";

import { fade, makeStyles } from "@material-ui/core/styles";

import Select from "@material-ui/core/Select";
import InputLabel from "@material-ui/core/InputLabel";
import FormControl from "@material-ui/core/FormControl";
import MenuItem from "@material-ui/core/MenuItem";

import TabsComponent from "../../components/Tabs";

import "./DocumentList.css";
import DataTable from "./DataTable";

const propTypes = {
  location: PropTypes.shape({
    pathname: PropTypes.string,
    search: PropTypes.string,
  }).isRequired,
  history: PropTypes.shape({ push: PropTypes.func }).isRequired,
};

const useStyles = makeStyles((theme) => ({
  root: {
    display: "flex",
    alignItems: "center",
    flexWrap: "wrap",
    "& .MuiSelect-icon": {
      width: "24px !important",
      height: "24px !important",
    },
    "& .MuiOutlinedInput-input": {
      padding: "12px",
    },
    "& .MuiInputLabel-outlined": {
      transform: "translate(14px, 14px) scale(1)",
    },
    "& .MuiInputLabel-outlined.MuiInputLabel-shrink": {
      transform: "translate(10px, -10px) scale(0.75)",
    },
  },
  search: {
    position: "relative",
    borderRadius: theme.shape.borderRadius,
    backgroundColor: fade(theme.palette.common.white, 0.15),
    "&:hover": {
      backgroundColor: fade(theme.palette.common.white, 0.25),
    },
    marginRight: theme.spacing(2),
    marginLeft: 0,
    width: "100%",
    minWidth: 650,
    marginBottom: "8px",
    border: "1px solid gray",
  },
  searchIcon: {
    padding: theme.spacing(0, 2),
    height: "100%",
    position: "absolute",
    pointerEvents: "none",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    "& svg": {
      height: "0.5em",
    },
  },
  inputRoot: {
    color: "inherit",
    width: "inherit",
  },
  inputInput: {
    padding: theme.spacing(1, 1, 1, 0),
    // vertical padding + font size from searchIcon
    paddingLeft: `calc(1em + ${theme.spacing(4)}px)`,
    transition: theme.transitions.create("width"),
    width: "100%",
  },
  formControl: {
    marginTop: theme.spacing(1),
    marginBottom: theme.spacing(0.5),
    width: "100%",
  },
}));

const columns = [
  "y_2016",
  "y_2017",
  "y_2018",
  "y_2019",
  "y_2020",
  "FieldName",
  "DataProvider",
  "BvD_9",
  "BvD_ID",
  "CompanyName",
  "NameOfDocument",
  "Section_of_Document",
  "PageNumbers",
  "Units_of_Measure_in_Company_Document",
  "Notes_Formula_or_Assumptions",
  "Existence_of_Policy_or_Process",
  "Text Supporting existence- Note-For Policy existence questions it may be best to show results by key word",
  "Format_number_or_text",
  "Data_Element_Label_Scope_1",
];

const nestArray = d3Collection
  .nest()
  .key((d) => d.CompanyName)
  .entries(listJsonData);

console.log(nestArray);

const DocumentList = (props) => {
  const classes = useStyles();
  const [nestState, setNestState] = useState(nestArray);
  const [filterValue, setFilterValue] = useState("");
  let tabList = [];

  function handleOnClick(newValue) {
    setNestState(nestArray);
    setFilterValue("All");
  }

  //function to handle filter
  function handleChange(e, itemKey) {
    setFilterValue(e.target.value);
    if (e.target.value === "All") {
      setNestState(nestArray);
    } else {
      const selectedKeyArray = nestState.filter((item) => item.key === itemKey);

      setNestState([
        {
          key: itemKey,
          values: Object.values(selectedKeyArray[0].values).filter(
            (item) => item[e.target.value]
          ),
        },
      ]);
    }
  }

  nestArray.map((item) =>
    tabList.push({
      title: item.key,
      component: (
        <>
          <div className={classes.root}>
            <FormControl
              variant="outlined"
              required
              className={classes.formControl}
            >
              <InputLabel id="demo-simple-select-outlined-label">
                Slice Using Columns
              </InputLabel>
              <Select
                labelId="demo-simple-select-outlined-label"
                id="demo-simple-select-outlined"
                value={filterValue}
                onChange={(e) => handleChange(e, item.key)}
                label="filter"
              >
                <MenuItem key={"All"} value={"All"}>
                  All
                </MenuItem>
                {columns.map((col) => (
                  <MenuItem key={col} value={col}>
                    {col}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
          </div>
          <DataTable
            selectedCompany={item.key}
            listJsonData={nestState}
            columns={columns}
          />
        </>
      ),
      disabled: false,
    })
  );

  return (
    <TabsComponent
      tabList={tabList}
      orientation={"vertical"}
      handleOnClick={handleOnClick}
      hasOnClick={true}
    />
  );
};

DocumentList.propTypes = propTypes;
export default DocumentList;
