/* eslint-disable react/jsx-props-no-spreading */
import React from "react";
import PropTypes from "prop-types";

import { makeStyles } from "@material-ui/core/styles";
import Tabs from "@material-ui/core/Tabs";
import Tab from "@material-ui/core/Tab";
import Box from "@material-ui/core/Box";

function TabPanel(props) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`scrollable-auto-tabpanel-${index}`}
      aria-labelledby={`scrollable-auto-tab-${index}`}
      {...other}
    >
      {value === index && <Box p={3}>{children}</Box>}
    </div>
  );
}

TabPanel.propTypes = {
  children: PropTypes.node,
  index: PropTypes.any.isRequired,
  value: PropTypes.any.isRequired,
};

function a11yProps(index) {
  return {
    id: `scrollable-auto-tab-${index}`,
    "aria-controls": `scrollable-auto-tabpanel-${index}`,
  };
}

const useStyles = makeStyles((theme) => ({
  root: {
    flexGrow: 1,
    width: "100%",
    backgroundColor: theme.palette.background.paper,
  },
  verticalRoot: {
    flexGrow: 1,
    backgroundColor: theme.palette.background.paper,
    display: "flex",
    height: "100%",
  },
  tabs: {
    borderRight: `1px solid ${theme.palette.divider}`,
    minWidth: "200px",
  },
}));

const propTypes = {
  tabList: PropTypes.array.isRequired,
  orientation: PropTypes.string,
  handleOnClick: PropTypes.func,
  hasOnClick: PropTypes.bool,
};

const defaultProps = {
  orientation: "horizontal",
  handleOnClick: () => {},
  hasOnClick: false,
};

const TabsComponent = ({ tabList, orientation, handleOnClick, hasOnClick }) => {
  const classes = useStyles();
  const [value, setValue] = React.useState(0);

  const handleChange = (event, newValue) => {
    setValue(newValue);
    if (hasOnClick) handleOnClick(newValue);
  };

  return (
    <div
      className={
        orientation === "vertical" ? classes.verticalRoot : classes.root
      }
    >
      <Tabs
        orientation={orientation}
        value={value}
        onChange={handleChange}
        indicatorColor="primary"
        textColor="primary"
        variant="scrollable"
        scrollButtons="auto"
        aria-label="scrollable auto tabs example"
        className={orientation === "vertical" ? classes.tabs : ""}
      >
        {tabList.map((tab, index) => (
          <Tab
            key={`tab-${tab.title}`}
            label={tab.title}
            {...a11yProps(index)}
            disabled={tab.disabled}
          />
        ))}
      </Tabs>

      {tabList.map((tab, index) => (
        <TabPanel key={`tab-panel-${tab.title}`} index={index} value={value}>
          {tab.component}
        </TabPanel>
      ))}
    </div>
  );
};
TabsComponent.defaultProps = defaultProps;
TabsComponent.propTypes = propTypes;
export default TabsComponent;
