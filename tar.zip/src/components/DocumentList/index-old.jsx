/* eslint-disable react/no-array-index-key */
/* eslint-disable eqeqeq */
/* eslint-disable jsx-a11y/control-has-associated-label */
/* eslint-disable jsx-a11y/anchor-has-content */
/* eslint-disable react/no-deprecated */
import React, { Component } from 'react';
import './DocumentList.css';
import * as d3Collection from 'd3-collection';
import PopUp from '../PopUp';
import lisiJsonData from '../../data/documentListJsonData';
import ActionButton from './ActionButton';
import AddFilter from './AddFilter';
import SearchBox from './SearchBox';

class DocumentListOld extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isToggleOn: false,
      isTogglePopup: false,
      listIndex: '',
      searchString: '',
      lables: [
        'y_2016',
        'y_2017',
        'y_2018',
        'y_2019',
        'y_2020',
        'FieldName',
        'DataProvider',
        'BvD_9',
        'BvD_ID',
        'CompanyName',
        'NameOfDocument',
        'Section_of_Document',
        'PageNumbers',
        'Units_of_Measure_in_Company_Document',
        'Notes_Formula_or_Assumptions',
        'Existence_of_Policy_or_Process',
        'Text Supporting existence- Note-For Policy existence questions it may be best to show results by key word',
        'Format_number_or_text',
        'Data_Element_Label_Scope_1',
      ],
    };
    this.state.filedata = [];
    this.state.filefilterdata = [];
  }

  componentWillMount() {
    const nest = d3Collection
      .nest()
      .key((d) => d.CompanyName)
      .entries(lisiJsonData);
    this.state.filedata = lisiJsonData;
    this.state.filefilterdata = nest;
  }

  togglePop = () => {
    this.setState((state) => ({
      isTogglePopup: !state.isTogglePopup,
    }));
  };

  onHandleChange = ({ target: { value } }) => {
    this.setState({ searchString: value });
  };

  handleFileClick = (e) => {
    const { listIndex, isToggleOn } = this.state;
    const index = e.target.getAttribute('data-index');

    if (index === listIndex) {
      this.setState({ isToggleOn: !isToggleOn });
    } else {
      this.setState({ isToggleOn: true });
    }
    this.setState({ listIndex: index });
  };

  searchFilter = () => {
    const finaldata = [];
    const { filedata, searchString } = this.state;
    filedata
      .filter((file) => file.Keywords.includes(searchString))
      .map((item) => finaldata.push(item));
    const filternest = d3Collection
      .nest()
      .key(({ CompanyName }) => CompanyName)
      .entries(finaldata);
    this.setState({ filefilterdata: filternest });
  };

  reloadPage = () => {
    window.location.reload();
  };

  render() {
    const {
      searchString,
      isTogglePopup,
      filefilterdata,
      listIndex,
      isToggleOn,
      lables,
    } = this.state;
    return (
      <>
        {isTogglePopup ? <PopUp toggle={this.togglePop} /> : null}
        <div className="mainDiv">
          <div className="row">
            <div className="col-md-9">
              <nav className="navbar navbar-inverse">
                <div className="container-fluid">
                  <div className="navbar-header">
                    <button
                      type="button"
                      className="navbar-toggle"
                      data-toggle="collapse"
                      data-target="#myNavbar"
                    >
                      <span className="icon-bar" />
                      <span className="icon-bar" />
                      <span className="icon-bar" />
                    </button>
                    <a className="navbar-brand" href="#" />
                  </div>
                  <ActionButton reloadPage={this.reloadPage} />
                </div>
              </nav>
              <SearchBox
                searchString={searchString}
                handleChange={this.onHandleChange}
                searchFilter={this.searchFilter}
              />
              {filefilterdata.map((file, i) => (
                <div className="panel panel-default">
                  <div
                    className="panel-heading"
                    style={{ backgroundColor: '#fff' }}
                    data-index={i}
                    onClick={this.handleFileClick}
                    key={i}
                  >
                    <span style={{ cursor: 'pointer' }}>
                      {isToggleOn && listIndex == i ? (
                        <i className="glyphicon glyphicon-triangle-bottom toggal-icon" />
                      ) : (
                        <i className="glyphicon glyphicon-triangle-right toggal-icon" />
                      )}
                    </span>
                    {file.key}
                  </div>
                  {isToggleOn && listIndex == i ? (
                    <div className="panel-body file-body">
                      <table className="table table-bordered">
                        <tbody>
                          {lables.map((lbl, j) => (
                            <tr key={lables[j]}>
                              <th>{lables[j]}</th>
                              {file.values.map((filedata, k) => (
                                <td key={`${lables[j]}_${k}`}>{filedata[lables[j]]}</td>
                              ))}
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  ) : null}
                </div>
              ))}
            </div>
            <div className="col-md-3">
              <AddFilter togglePop={this.togglePop} />
            </div>
          </div>
        </div>
      </>
    );
  }
}

export default DocumentListOld;
