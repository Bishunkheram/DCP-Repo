/* eslint-disable react/jsx-props-no-spreading */
import React from 'react';
import { BrowserRouter as Router } from 'react-router-dom';
import './App.css';
import Routes from './components/Routes';

const App = (props) => (
  <Router>
    <Routes {...props} />
  </Router>
);

export default App;
