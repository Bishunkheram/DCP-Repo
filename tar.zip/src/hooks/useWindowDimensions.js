import { useState, useEffect } from "react";

function getWindowDimensions() {
  const {
    innerWidth: width,
    innerHeight: height,
    pageYOffset: scrollOffset,
  } = window;

  let isMobile =
    (height > width && width < 768) || height === width || width < 768 || window.orientation === 90 || window.orientation === -90;
  const isMobileAndLandscape =
    window.orientation === 90 || window.orientation === -90;

  if (height <= 450 && isMobileAndLandscape) {
    isMobile = true;
  }

  return {
    width,
    height,
    scrollOffset,
    isMobile,
    isMobileAndLandscape,
  };
}

export default function useWindowDimensions() {
  const [windowDimensions, setWindowDimensions] = useState(
    getWindowDimensions()
  );

  useEffect(() => {
    function handleResize() {
      setWindowDimensions(getWindowDimensions());
    }

    function handleScroll() {
      setWindowDimensions(getWindowDimensions());
    }

    window.addEventListener("scroll", handleScroll);
    window.addEventListener("resize", handleResize);
    return () => {
      window.removeEventListener("resize", handleResize);
      window.removeEventListener("scroll", handleScroll);
    };
  }, []);

  return windowDimensions;
}
