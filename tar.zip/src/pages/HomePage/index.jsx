/* eslint-disable react/jsx-props-no-spreading */
import React, { useEffect } from "react";
import { withRouter } from "react-router-dom";
import { makeStyles } from "@material-ui/core/styles";
import PropTypes from "prop-types";
import _ from "lodash";

import Grid from "@material-ui/core/Grid";
import TextField from "@material-ui/core/TextField";
import Select from "@material-ui/core/Select";
import InputLabel from "@material-ui/core/InputLabel";
import FormControl from "@material-ui/core/FormControl";
// Layout
import Layout from "../../layouts/index";
// Components
import HomeDocumentForm from "./HomePageForm/index";
import TabsComponent from "../../components/Tabs";
import FileUpload from "../../components/FileUpload";

// Utils
import { SUPPORTED_FILE_TYPES } from "../../utils";

import XLSX from "xlsx";
import Button from "@material-ui/core/Button";
import AlertsComponent from "../../components/Alert";
import useWindowDimensions from "../../hooks/useWindowDimensions";
import { MenuItem } from "@material-ui/core";
import DataTableComponent from "../../components/DataTable";

const propTypes = {
  location: PropTypes.shape({
    pathname: PropTypes.string,
    search: PropTypes.string,
  }).isRequired,
  history: PropTypes.shape({ push: PropTypes.func }).isRequired,
};

const useStyles = makeStyles((theme) => ({
  root: {
    display: "flex",
    alignItems: "center",
    flexWrap: "wrap",
    "& .MuiSelect-icon": {
      width: "24px !important",
      height: "24px !important",
    },
    "& .MuiOutlinedInput-input": {
      padding: "12px",
    },
    "& .MuiInputLabel-outlined": {
      transform: "translate(14px, 14px) scale(1)",
    },
    "& .MuiInputLabel-outlined.MuiInputLabel-shrink": {
      transform: "translate(10px, -10px) scale(0.75)",
    },
  },
  formControl: {
    marginTop: theme.spacing(1),
    marginBottom: theme.spacing(0.5),
    width: "100%",
  },
  textField: {
    width: "100%",
  },
  saveButton: {
    minWidth: "94px",
  },
}));

const HomePage = (props) => {
  const classes = useStyles();
  const { isMobile } = useWindowDimensions();
  const pageName = "Home";
  const { location, history } = props;
  const FILE_LIMIT = 1;
  const [files, setFiles] = React.useState([]);
  const [isValidFile, setIsValidFile] = React.useState(true);
  const [uploadedExcelData, setUploadedExcelData] = React.useState([]);
  const [excelData, setExcelData] = React.useState([]);
  const [template, setTemplate] = React.useState(1);
  const [templateList, setTemplateList] = React.useState([]);
  const [user,setUser] = React.useState('');
  const [comment,setComment] = React.useState('');

  const fetchURL = "http://localhost:8000";

  // to get all the templated
  const getTemplates = () =>
    fetch(`${fetchURL}/templates`).then((res) => res.json());

  // to get excel data by template id
  const getExcelDataByTemplateId = (template_id) =>
    fetch(`${fetchURL}/excelData?template_id=${template_id}`).then((res) =>
      res.json()
    );

  // to update the record in db.json file
  const updateExcelData = (excelDataId, body) =>
    fetch(`${fetchURL}/excelData/${excelDataId}`, {
      method: "PATCH",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(body), // We send data in JSON format
    }).then((res) => res.json());

  // Function handles the file selection and removal on click delete button from selected file list
  function handleFileChange(fileList, index = -1, removeFlag = false) {
    if (removeFlag) {
      // handles deleting file
      setFiles([]);
      handleFile([]);
      handleExcelUpload([]);
    } else {
      // handles files selection
      setFiles(fileList);
      handleFile(fileList);
      handleExcelUpload(fileList);
    }
  }

  const handleChangeTemplate = (e) => {
    // update state for the template id and reset the state for excelData and uploaded excel data
    setTemplate(e.target.value);
    setExcelData([]);
    setUploadedExcelData([]);
  };

  const handleUserChange = (e)=>{
    setUser(e.target.value)
  }

  const handleCommentChange  = (e)=>{
    setComment(e.target.value)
  }

  const handleFile = (filesL) => {
    /* Boilerplate to set up FileReader */
    const reader = new FileReader();
    const rABS = !!reader.readAsBinaryString;

    reader.onload = (e) => {
      /* Parse data */
      const bstr = e.target.result;
      const wb = XLSX.read(bstr, {
        type: rABS ? "binary" : "array",
        bookVBA: true,
        sheetRows: 1,
      });
      /* Get first worksheet */
      const wsname = wb.SheetNames[0];
      const ws = wb.Sheets[wsname];

      const FILE_SCHEMA = XLSX.utils.sheet_to_json(ws, {
        header: 1,
      });

      // to check if selected file validated selected template schema
      const isValid = _.isEqual(
        templateList.find((e) => e.id === template)?.schema,
        FILE_SCHEMA[0]
      );

      setIsValidFile(isValid);

      if (!isValid) {
        setFiles([]);
        handleFile([]);
      }
    };

    if (filesL && filesL.length > 0) {
      if (rABS) {
        reader.readAsBinaryString(filesL[0]["file"]);
      } else {
        reader.readAsArrayBuffer(filesL[0]["file"]);
      }
    }
  };

  const handleExcelUpload = (filesL) => {
    if (filesL && filesL.length === 0) setExcelData([]);

    /* Boilerplate to set up FileReader */
    const reader = new FileReader();
    const rABS = !!reader.readAsBinaryString;

    reader.onload = (e) => {
      /* Parse data */
      const bstr = e.target.result;
      const wb = XLSX.read(bstr, {
        type: rABS ? "binary" : "array",
        bookVBA: true,
      });
      /* Get first worksheet */
      const wsname = wb.SheetNames[0];
      const ws = wb.Sheets[wsname];
      /* Convert array of arrays */
      const data = XLSX.utils.sheet_to_json(ws);
      /* Update state */
      setUploadedExcelData(data);
    };

    if (filesL && filesL.length > 0) {
      if (rABS) {
        reader.readAsBinaryString(filesL[0]["file"]);
      } else {
        reader.readAsArrayBuffer(filesL[0]["file"]);
      }
    }
  };

  const handleSubmitForm = async (e) => {
    e.preventDefault();
    /* if current template selected and also there is some data to upload then we are going to call an api */
    if (template && uploadedExcelData.length) {
      try {
        const currentExcelDataRecordArray = await getExcelDataByTemplateId(
          template
        );
        let excelRecord = currentExcelDataRecordArray[0];
        const existingData = (excelRecord && excelRecord.data) || [];

        /* append new data with the old data*/
        const newData = [...uploadedExcelData];
        newData.forEach(e=>{
          e.user = user;
          e.comment=comment
        })
        const data = [...existingData, ...newData];
        const updated = await updateExcelData(excelRecord.id, { data });
        /* update state */
        setExcelData(updated.data);
      } catch (error) {}
    }
  };

  const tabList = [
    {
      title: "PDF UPLOAD",
      component: <HomeDocumentForm {...props} />,
      disabled: false,
    },
    {
      title: "EXCEL UPLOAD",
      component: (
        <>
          <FileUpload
            handleFileChange={handleFileChange}
            supportedFileTypes={SUPPORTED_FILE_TYPES.EXCEL.MIME_TYPE}
            fileLimit={FILE_LIMIT}
            fileList={files} // prop of selected files list, to preview files selected
            showAlerts={isValidFile} // prop when upload file is invalid alert is not shown
          />
          <form onSubmit={handleSubmitForm}>
            <div className={classes.root}>
              <Grid container spacing={isMobile ? 0 : 3}>
                <Grid item xs={isMobile ? 12 : 4}>
                  <TextField
                    label="User Name *"
                    id="outlined-margin-dense"
                    className={classes.textField}
                    helperText=""
                    margin="dense"
                    value={user}
                    onChange={handleUserChange}
                    variant="outlined"
                  />

                  <FormControl
                    variant="outlined"
                    required
                    className={classes.formControl}
                  >
                    <InputLabel id="demo-simple-select-outlined-label">
                      Category Of Document
                    </InputLabel>
                    <Select
                      labelId="demo-simple-select-outlined-label"
                      id="demo-simple-select-outlined"
                      value={template}
                      onChange={handleChangeTemplate}
                      label="Age"
                    >
                      {templateList.map((e) => (
                        <MenuItem key={e.id} value={e.id}>
                          {e.name}
                        </MenuItem>
                      ))}
                    </Select>
                  </FormControl>

                  <TextField
                    label="Comments"
                    id="outlined-margin-dense"
                    helperText=""
                    margin="dense"
                    value={comment}
                    onChange={handleCommentChange}
                    variant="outlined"
                    className={classes.textField}
                    multiline={true}
                    rows={8}
                  />

                  <Button
                    variant="contained"
                    color="primary"
                    type="submit"
                    className={classes.saveButton}
                  >
                    SUBMIT
                  </Button>
                  <Button
                    variant="contained"
                    color="primary"
                    className={classes.saveButton}
                  >
                    RESET
                  </Button>
                  <br />
                </Grid>
              </Grid>
              {excelData && excelData.length > 0 && (
                <DataTableComponent
                  tableHeaders={
                    [...templateList.find((e) => e.id === template)?.schema,...['user','comment']]
                  }
                  tableRows={excelData}
                />
              )}
            </div>
          </form>
        </>
      ),
      disabled: false,
    },
  ];

  useEffect(() => {
    getTemplates().then((data) => {
      setTemplateList(data);
    });
  }, []);

  return (
    <Layout page={pageName} location={location} history={history}>
      {!isValidFile && (
        <AlertsComponent
          type={isValidFile ? "success" : "error"}
          message={
            isValidFile
              ? "Uploaded file is valid"
              : "Uploaded file is not valid"
          }
        />
      )}
      <TabsComponent tabList={tabList} />
    </Layout>
  );
};

HomePage.propTypes = propTypes;
export default withRouter(HomePage);
