import React, { useCallback } from "react";

import { makeStyles } from "@material-ui/core/styles";
import TextField from "@material-ui/core/TextField";
import Select from "@material-ui/core/Select";
import InputLabel from "@material-ui/core/InputLabel";
import FormControl from "@material-ui/core/FormControl";
import Grid from "@material-ui/core/Grid";

import FileUpload from "../../../components/FileUpload";
import MenuItem from "@material-ui/core/MenuItem";
import "./HomePageForm.css";
import useWindowDimensions from "../../../hooks/useWindowDimensions";
import { SUPPORTED_FILE_TYPES } from "../../../utils";
import Button from "@material-ui/core/Button";

const useStyles = makeStyles((theme) => ({
  root: {
    display: "flex",
    alignItems: "center",
    flexWrap: "wrap",
    "& .MuiSelect-icon": {
      width: "24px !important",
      height: "24px !important",
    },
    "& .MuiOutlinedInput-input": {
      padding: "12px",
    },
    "& .MuiInputLabel-outlined": {
      transform: "translate(14px, 14px) scale(1)",
    },
    "& .MuiInputLabel-outlined.MuiInputLabel-shrink": {
      transform: "translate(10px, -10px) scale(0.75)",
    },
  },
  formControl: {
    marginTop: theme.spacing(1),
    marginBottom: theme.spacing(0.5),
    width: "100%",
  },
  textField: {
    width: "100%",
  },
  saveButton: {
    minWidth: "94px",
  },
}));

const HomePageForm = () => {
  const classes = useStyles();
  const [files, setFiles] = React.useState([]);
  const [age, setAge] = React.useState("");
  const { isMobile } = useWindowDimensions();
  const FILE_LIMIT = 5;

  const handleChange = (event) => {
    setAge(event.target.value);
  };

  // Function handles the file selection and removal on click delete button from selected file list
  const handleFileChange = (fileList, index = -1, removeFlag = false) => {
    if (removeFlag) { // handles deleting file
      const filesArray = files;
      filesArray.splice(index, 1);
      setFiles([...filesArray]);
    } else { // handles files selection
      if (FILE_LIMIT === 1) {
        setFiles(fileList);
      } else {
        setFiles((filesArray) => [...filesArray, ...fileList]);
      }
    }
  };

  return (
    <>
      <FileUpload
        handleFileChange={handleFileChange}
        supportedFileTypes={SUPPORTED_FILE_TYPES.PDF.MIME_TYPE}
        fileLimit={FILE_LIMIT}
        fileList={files}
      />
      <div className={classes.root}>
        <Grid container spacing={isMobile ? 0 : 3}>
          <Grid item xs={isMobile ? 12 : 4}>
            <TextField
              label="BvD9 ID"
              id="outlined-margin-dense"
              defaultValue=""
              className={classes.textField}
              helperText=""
              margin="dense"
              variant="outlined"
            />

            <TextField
              label="VE ID"
              id="outlined-margin-dense"
              defaultValue=""
              className={classes.textField}
              helperText=""
              margin="dense"
              variant="outlined"
            />

            <TextField
              label="Company Name"
              id="outlined-margin-dense"
              defaultValue=""
              className={classes.textField}
              helperText=""
              margin="dense"
              variant="outlined"
            />

            <TextField
              label="Comments"
              id="outlined-margin-dense"
              defaultValue=""
              helperText=""
              margin="dense"
              variant="outlined"
              className={classes.textField}
              multiline={true}
              rows={8}
            />
          </Grid>
          <Grid item xs={isMobile ? 12 : 4}>
            <FormControl
              variant="outlined"
              required
              className={classes.formControl}
            >
              <InputLabel id="demo-simple-select-outlined-label">
                Category Of Document
              </InputLabel>
              <Select
                labelId="demo-simple-select-outlined-label"
                id="demo-simple-select-outlined"
                value={age}
                onChange={handleChange}
                label="Age"
              >
                <MenuItem value={10}>Ten</MenuItem>
                <MenuItem value={20}>Twenty</MenuItem>
                <MenuItem value={30}>Thirty</MenuItem>
              </Select>
            </FormControl>

            <TextField
              label="Name Of Document"
              id="outlined-margin-dense"
              defaultValue=""
              className={classes.textField}
              helperText=""
              margin="dense"
              variant="outlined"
            />
            <FormControl
              variant="outlined"
              required
              className={classes.formControl}
            >
              <InputLabel id="demo-simple-select-outlined-label">
                Source of the Document
              </InputLabel>
              <Select
                labelId="demo-simple-select-outlined-label"
                id="demo-simple-select-outlined"
                value={age}
                onChange={handleChange}
                label="Age"
              >
                <MenuItem value={10}>Ten</MenuItem>
                <MenuItem value={20}>Twenty</MenuItem>
                <MenuItem value={30}>Thirty</MenuItem>
              </Select>
            </FormControl>
          </Grid>
          <Grid item xs={isMobile ? 12 : 4}>
            <FormControl
              variant="outlined"
              required
              margin="dense"
              className={classes.formControl}
            >
              <InputLabel id="demo-simple-select-outlined-label">
                Published Date
              </InputLabel>
              <Select
                labelId="demo-simple-select-outlined-label"
                id="demo-simple-select-outlined"
                value={age}
                onChange={handleChange}
                label="Age"
              >
                <MenuItem value={10}>Ten</MenuItem>
                <MenuItem value={20}>Twenty</MenuItem>
                <MenuItem value={30}>Thirty</MenuItem>
              </Select>
            </FormControl>

            <TextField
              label="URL for Document"
              id="outlined-margin-dense"
              defaultValue=""
              className={classes.textField}
              helperText=""
              margin="dense"
              variant="outlined"
            />

            <FormControl
              variant="outlined"
              required
              className={classes.formControl}
            >
              <InputLabel id="demo-simple-select-outlined-label">
                Standalone Document
              </InputLabel>
              <Select
                labelId="demo-simple-select-outlined-label"
                id="demo-simple-select-outlined"
                value={age}
                onChange={handleChange}
                label="Age"
              >
                <MenuItem value={10}>Ten</MenuItem>
                <MenuItem value={20}>Twenty</MenuItem>
                <MenuItem value={30}>Thirty</MenuItem>
              </Select>
            </FormControl>
          </Grid>
        </Grid>
        <br />
        <Button
          variant="contained"
          color="primary"
          className={classes.saveButton}
        >
          SAVE
        </Button>
      </div>
    </>
  );
};

export default HomePageForm;
