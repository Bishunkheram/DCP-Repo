/* eslint-disable no-console */
/* eslint-disable react/prop-types */
import React from "react";
import PropTypes from "prop-types";
import { Redirect, withRouter } from "react-router-dom";
import { useOktaAuth } from "@okta/okta-react";
import OktaSignInWidget from "../../components/OktaSignInWidget";
import Header from "../../components/Header";

const propTypes = {
  history: PropTypes.shape({ push: PropTypes.func }).isRequired,
};

const Login = ({ config, history }) => {
  const { oktaAuth, authState } = useOktaAuth();
  const pageName = "Login";

  const onSuccess = (tokens) => {
    oktaAuth.handleLoginRedirect(tokens);
  };

  const onError = (err) => {
    console.log("error logging in", err);
  };

  if (authState.isPending) return null;
  else console.log("---authState----", authState);

  return authState.isAuthenticated ? (
    <Redirect to={{ pathname: "/home" }} />
  ) : (
    <>
      <Header open={false} history={history} page={pageName} />
      <OktaSignInWidget
        config={config}
        onSuccess={onSuccess}
        onError={onError}
      />
    </>
  );
};

Login.propTypes = propTypes;
export default withRouter(Login);
