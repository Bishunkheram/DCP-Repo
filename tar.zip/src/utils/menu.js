/* eslint-disable react/react-in-jsx-scope */
/* eslint-disable react/jsx-filename-extension */
import HomeIcon from '@material-ui/icons/Home';
import InsertChartIcon from '@material-ui/icons/InsertChart';
import EmojiObjectsIcon from '@material-ui/icons/EmojiObjects';

const menuList = [
  { title: 'HOME', path: '/home', icon: <HomeIcon /> },
  { title: 'VISUALIZE', path: '/visualize', icon: <InsertChartIcon /> },
  { title: 'DISCOVER', path: '/discover', icon: <EmojiObjectsIcon /> },
];

export default menuList;
