/* eslint-disable arrow-body-style */
import React from 'react';
import PropTypes from 'prop-types';

import { makeStyles } from '@material-ui/core/styles';

import s from './Layout.css';
import Footer from '../components/Footer';
import Header from '../components/Header';
import SideMenu from '../components/SideMenu';

const propTypes = {
  history: PropTypes.shape({}),
  children: PropTypes.node.isRequired,
  page: PropTypes.string.isRequired,
  style: PropTypes.shape({}),
};

const defaultProps = {
  history: {},
  style: {},
};

const useStyles = makeStyles((theme) => ({
  root: {
    display: 'flex',
  },
  toolbar: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'flex-end',
    padding: theme.spacing(0, 1),
    // necessary for content to be below app bar
    ...theme.mixins.toolbar,
  },
  content: {
    flexGrow: 1,
    padding: theme.spacing(3),
  },
}));

const Layout = ({ children, page, history, style }) => {
  const classes = useStyles();
  const [open, setOpen] = React.useState(false);

  const handleDrawerOpen = () => {
    setOpen(true);
  };

  const handleDrawerClose = () => {
    setOpen(false);
  };

  return (
    <div className={[s.bg, classes.root].join(' ')} style={style}>
      <Header page={page} history={history} open={open} />
      <SideMenu
        open={open}
        handleDrawerClose={handleDrawerClose}
        handleDrawerOpen={handleDrawerOpen}
      />

      <main className={classes.content}>
        <div className={classes.toolbar} />
        {children}
      </main>
      <Footer page={page} />
    </div>
  );
};
Layout.defaultProps = defaultProps;
Layout.propTypes = propTypes;
export default Layout;
