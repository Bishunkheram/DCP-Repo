/* eslint-disable no-console */
/* eslint-disable react/prop-types */
import React from "react";
import { Redirect } from "react-router-dom";
import { useOktaAuth } from "@okta/okta-react";
import OktaSignIn from "@okta/okta-signin-widget";
import OktaSignInWidget from "../../components/OktaSignInWidget";
import Header from "../../components/Header";

const Login = ({ config }) => {
  const { oktaAuth, authState } = useOktaAuth();
  //console.log("--------------config",config);
  const signInWidget = new OktaSignIn({
    baseUrl: "https://mss-moodys.oktapreview.com",
    clientId: "0oa9lgkdxFA2QYAQS1d6",
  });
  // console.log("--------------config",config);
  signInWidget.authClient.session.get().then((res1) => {
    // Session exists, show logged in state.
    // console.log('Session Status', res1);
    if (res1.status === "ACTIVE") {
      signInWidget.authClient.token
        .getWithoutPrompt({})
        .then((res2) => {
          //          console.log('Active status', res2);
          signInWidget.authClient.tokenManager.add(
            "idToken",
            res2.tokens.idToken
          );
          signInWidget.authClient.tokenManager.add(
            "accessToken",
            res2.tokens.accessToken
          );
        })
        .catch((error) => {
          console.error(error);
        });
    }
  });

  const onSuccess = (tokens) => {
    // console.log('-----tokens----', tokens);
    oktaAuth.handleLoginRedirect(tokens);
  };

  const onError = (err) => {
    console.log("error logging in", err);
  };

  if (authState.isPending) return null;

  return authState.isAuthenticated ? (
    <Redirect to={{ pathname: "/home" }} />
  ) : (
    <>
      <Header />

      <OktaSignInWidget
        config={config}
        onSuccess={onSuccess}
        onError={onError}
      />
    </>
  );
};
export default Login;
