import React from 'react';

const Protected = () => <h3>Protected</h3>;
export default Protected;