/* eslint-disable react/jsx-props-no-spreading */
import React from 'react';
import Visualization from '../../components/Visualization';
// import Header from '../../components/Header';
// import SideMenu from '../../components/SideMenu';
import { withRouter } from 'react-router-dom';
import PropTypes from 'prop-types';

// Layout
import Layout from '../../layouts/index';

const propTypes = {
  location: PropTypes.shape({ pathname: PropTypes.string, search: PropTypes.string }).isRequired,
  history: PropTypes.shape({ push: PropTypes.func }).isRequired,
};

const Visualize = (props) => {
  const  pageName  = 'Visualize';
  const { location } = props;
  return (
    <Layout page={pageName} location={location}>
    <Visualization {...props} />
    </Layout>
   );
  };

Visualize.propTypes = propTypes;
export default withRouter(Visualize);

