import React, { useState, useEffect } from "react";
// import XLSX from "xlsx";
import Grid from "@material-ui/core/Grid";
import TextField from "@material-ui/core/TextField";
import Select from "@material-ui/core/Select";
import InputLabel from "@material-ui/core/InputLabel";
import FormControl from "@material-ui/core/FormControl";
import Button from "@material-ui/core/Button";
import { MenuItem } from "@material-ui/core";
import { makeStyles } from "@material-ui/core/styles";
import axios from "axios";
import { useOktaAuth } from "@okta/okta-react";
// import _ from "lodash";

// components
import FileUpload from "../../../components/FileUpload";
import AlertsComponent from "../../../components/Alert";
import DataTableComponent from "../../../components/DataTable";
import { FullScreenDialog } from "../../../components/FullScreenDialog";

// Utils
import { SUPPORTED_FILE_TYPES } from "../../../utils";
import { exportAsExcelFile } from "../../../utils/downloadCSV";

// hooks
import useWindowDimensions from "../../../hooks/useWindowDimensions";

const useStyles = makeStyles((theme) => ({
  root: {
    display: "flex",
    alignItems: "center",
    flexWrap: "wrap",
    "& .MuiSelect-icon": {
      width: "24px !important",
      height: "24px !important",
    },
    "& .MuiOutlinedInput-input": {
      padding: "12px",
    },
    "& .MuiInputLabel-outlined": {
      transform: "translate(14px, 14px) scale(1)",
    },
    "& .MuiInputLabel-outlined.MuiInputLabel-shrink": {
      transform: "translate(10px, -10px) scale(0.75)",
    },
  },
  formControl: {
    marginTop: theme.spacing(1),
    marginBottom: theme.spacing(0.5),
    width: "100%",
  },
  textField: {
    width: "100%",
  },
  saveButton: {
    minWidth: "94px",
  },
}));

const CSVUploadForm = ({ openRoleSelectionModal }) => {
  const FILE_LIMIT = 1;
  const classes = useStyles();
  const { isMobile } = useWindowDimensions();
  const [files, setFiles] = useState([]);
  // const [uploadedExcelData, setUploadedExcelData] = useState([]);
  const [template, setTemplate] = useState("");
  const [user, setUser] = useState("");
  const [comment, setComment] = useState("");
  const [templateList, setTemplateList] = useState([]);
  const [modalDisplay, setModalDisplay] = useState(false);
  const [userInitial, setUserInitial] = useState("");
  const [isValidFile, setIsValidFile] = useState(true);
  const [responseData, setResponseData] = useState([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { oktaAuth, authState } = useOktaAuth();
  const [isClean, setIsClean] = useState(false);
  const templateData = templateList.find((t) => t.id === template);
  // const [excelData, setExcelData] = useState([]);

  useEffect(() => {
    let mounted = true;

    async function getUser() {
      const user = await oktaAuth.getUser();
      if (mounted) {
        setUser(`${user.firstName} ${user.lastName}`);
        setUserInitial(
          `${user.firstName.slice(0, 1).toUpperCase()}${user.lastName
            .slice(0, 1)
            .toUpperCase()}`
        );
      }
    }

    if (authState.isAuthenticated) {
      getUser();
    }

    return function cleanup() {
      mounted = false;
    };
  }, [authState.isAuthenticated, oktaAuth]);

  const bindTemplates = async () => {
    const response = await axios.get(
      "https://1qg6z5jg4g.execute-api.us-east-1.amazonaws.com/initial/template-list"
    );
    const templates = response.data.response.templates;
    setTemplateList(templates);
  };

  useEffect(() => {
    bindTemplates();
  }, []);

  // const handleExcelUpload = (filesL) => {
  //   // if (filesL && filesL.length === 0) setExcelData([]);

  //   /* Boilerplate to set up FileReader */
  //   const reader = new FileReader();
  //   const rABS = !!reader.readAsBinaryString;

  //   reader.onload = (e) => {
  //     /* Parse data */
  //     const bstr = e.target.result;
  //     const wb = XLSX.read(bstr, {
  //       type: rABS ? "binary" : "array",
  //       bookVBA: true,
  //     });
  //     /* Get first worksheet */
  //     const wsname = wb.SheetNames[0];
  //     // const ws = wb.Sheets[wsname];
  //     /* Convert array of arrays */
  //     // const data = XLSX.utils.sheet_to_json(ws);
  //     /* Update state */
  //     //setUploadedExcelData(data);
  //   };

  //   if (filesL && filesL.length > 0) {
  //     if (rABS) {
  //       reader.readAsBinaryString(filesL[0]["file"]);
  //     } else {
  //       reader.readAsArrayBuffer(filesL[0]["file"]);
  //     }
  //   }
  // };

  // const handleFile = (filesL) => {
  //   /* Boilerplate to set up FileReader */
  //   const reader = new FileReader();
  //   const rABS = !!reader.readAsBinaryString;

  //   reader.onload = (e) => {
  //     /* Parse data */
  //     const bstr = e.target.result;
  //     const wb = XLSX.read(bstr, {
  //       type: rABS ? "binary" : "array",
  //       bookVBA: true,
  //       sheetRows: 1,
  //     });
  //     /* Get first worksheet */
  //     const wsname = wb.SheetNames[0];
  //     const ws = wb.Sheets[wsname];

  //     const FILE_SCHEMA = XLSX.utils.sheet_to_json(ws, {
  //       header: 1,
  //     });

  //     // to check if selected file validated selected template schema
  //     const isValid = _.isEqual(
  //       templateList.find((e) => e.id === template)?.schema,
  //       FILE_SCHEMA[0]
  //     );

  //     setIsValidFile(isValid);

  //     if (!isValid) {
  //       setFiles([]);
  //       handleFile([]);
  //     }
  //   };

  //   if (filesL && filesL.length > 0) {
  //     if (rABS) {
  //       reader.readAsBinaryString(filesL[0]["file"]);
  //     } else {
  //       reader.readAsArrayBuffer(filesL[0]["file"]);
  //     }
  //   }
  // };

  const handleFileChange = (fileList, index = -1, removeFlag = false) => {
    if (removeFlag) {
      setFiles([]);
      // handleExcelUpload([]);
    } else {
      setFiles(fileList);
      // handleExcelUpload(fileList);
    }
  };

  const handleSubmitForm = async (e) => {
    e.preventDefault();
    const role = localStorage.getItem("role");
    if (!role) {
      openRoleSelectionModal();
      return;
    }
    console.log(role);

    setIsSubmitting(true);

    const formMetaData = new FormData();
    formMetaData.append("id", Date.now().toString());
    formMetaData.append("template_name", templateList[template].name);
    formMetaData.append("user", user);
    formMetaData.append("comment", comment);

    const metaDataApi =
      "https://1o9hapfjg7.execute-api.us-east-1.amazonaws.com/csv/metadata";
    const metaDataConfig = {
      headers: {
        "Content-Type": "multipart/form-data",
      },
    };

    try {
      const response = await axios.post(
        metaDataApi,
        formMetaData,
        metaDataConfig
      );
      if (response.status >= 200 && response.status < 300) {
      }
    } catch (error) {
      setIsSubmitting(false);
      console.log("formMetaData Error:", error);
    }

    try {
      const file = files[0].file;
      const formCSVData = new FormData();
      formCSVData.append("file", file);
      formCSVData.append(
        "fileName",
        `${userInitial}-${templateData.name}-test.csv`
      );

      const csvUploadApi =
        "https://mqrvafjoxl.execute-api.us-east-1.amazonaws.com/upload/excelupload";
      const csvUploadDyanmoConfig = {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      };
      const response3 = await axios.post(
        csvUploadApi,
        formCSVData,
        csvUploadDyanmoConfig
      );
      if (response3.status >= 200 && response3.status < 300) {
        setResponseData(response3.data.response);
        // handleCloseModal();
      }
    } catch (error) {
      console.log("formCSVData Error:", error);
      setIsSubmitting(false);
    }

    axios
      .get(
        `https://zs2ehfrzwl.execute-api.us-east-1.amazonaws.com/upload/s3-upload-csv?file=${userInitial}-${templateData.name}.csv`
      )
      .then((response) => {
        const file = files[0].file;
        var signedURL = response.data.URL;
        var csvUploadConfig = {
          headers: {
            "Content-Type": file.type,
          },
        };
        return axios
          .put(signedURL, file, csvUploadConfig)
          .then(function (res) {
            //alert("Success");
            setIsSubmitting(false);
            setModalDisplay(true);
          })
          .catch(function (error) {
            console.log(error);
            setIsSubmitting(false);
          });
      });

    // try {
    //   const url = `https://zs2ehfrzwl.execute-api.us-east-1.amazonaws.com/upload/s3-upload-csv?file=${userInitial}-${templateData.name}.csv`;
    //   const signedURL = await axios.get(url);
    //   const data = files[0].file;
    //   const csvUploadConfig = {
    //     headers: {
    //       "Content-Type": "text/csv",
    //     },
    //   };
    //   axios.put(signedURL.data.body, data, csvUploadConfig);
    //     setIsSubmitting(false);
    //     setModalDisplay(true);
    // } catch (error) {
    //   console.error(error);
    //   setIsSubmitting(false);
    // }
  };

  const handleReset = () => {
    setFiles([]);
    setIsValidFile(true);
    // setUploadedExcelData([]);
    // setExcelData([]);
    setTemplate("");
    setComment("");
  };

  const handleCloseModal = () => {
    setModalDisplay(false);
    handleReset();
  };

  const handleDownload = () => {
    exportAsExcelFile(responseData, `${userInitial}-${templateData.name}`);
  };

  const handleChangeTemplate = (e) => {
    // update state for the template id and reset the state for excelData and uploaded excel data
    setTemplate(e.target.value);
    // setExcelData([]);
    // setUploadedExcelData([]);
  };

  const handleUserChange = (e) => {
    setUser(e.target.value);
  };

  const handleCommentChange = (e) => {
    setComment(e.target.value);
  };

  return (
    <>
      {!isValidFile && (
        <AlertsComponent
          type={isValidFile ? "success" : "error"}
          message={
            isValidFile
              ? "Uploaded file is valid"
              : "Uploaded file is not valid"
          }
        />
      )}
      <FileUpload
        handleFileChange={handleFileChange}
        supportedFileTypes={SUPPORTED_FILE_TYPES.EXCEL.MIME_TYPE}
        fileLimit={FILE_LIMIT}
        fileList={files} // prop of selected files list, to preview files selected
        showAlerts={isValidFile} // prop when upload file is invalid alert is not shown
      />
      <form onSubmit={handleSubmitForm}>
        <div className={classes.root}>
          <Grid container spacing={isMobile ? 0 : 3}>
            <Grid item xs={isMobile ? 12 : 4}>
              <TextField
                label="User Name *"
                id="outlined-margin-dense"
                className={classes.textField}
                helperText=""
                margin="dense"
                value={user}
                onChange={handleUserChange}
                variant="outlined"
                disabled
              />

              <FormControl
                variant="outlined"
                required
                className={classes.formControl}
              >
                <InputLabel id="demo-simple-select-outlined-label">
                  Template Name
                </InputLabel>
                <Select
                  labelId="demo-simple-select-outlined-label"
                  id="demo-simple-select-outlined"
                  value={template}
                  onChange={handleChangeTemplate}
                  label="templateName"
                >
                  {templateList.map((e) => (
                    <MenuItem key={e.id} value={e.id}>
                      {e.name}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>

              <TextField
                label="Comments"
                id="outlined-margin-dense"
                helperText=""
                margin="dense"
                value={comment}
                onChange={handleCommentChange}
                variant="outlined"
                className={classes.textField}
                multiline={true}
                rows={8}
              />
            </Grid>
          </Grid>
          <div className={classes.root} style={{ marginTop: "5px" }}>
            <Button
              variant="contained"
              color="primary"
              type="submit"
              size="large"
              className={classes.saveButton}
              disabled={isSubmitting}
              style={{
                maxWidth: "200px",
                maxHeight: "100px",
                minWidth: "200px",
                minHeight: "20px",
              }}
            >
              SUBMIT
            </Button>

            <Button
              variant="contained"
              color="primary"
              size="large"
              className={classes.saveButton}
              onClick={handleReset}
              style={{
                maxWidth: "200px",
                maxHeight: "100px",
                minWidth: "200px",
                minHeight: "20px",
                marginLeft: "30px",
              }}
            >
              RESET
            </Button>
          </div>
          <br />
        </div>
      </form>
      <FullScreenDialog
        open={modalDisplay}
        handleClose={handleCloseModal}
        handleDownload={handleDownload}
      >
        {responseData && responseData.length > 0 && (
          <div>
            <DataTableComponent
              tableHeaders={
                templateList.find((e) => e.id === template)?.schema || []
              }
              tableRows={responseData}
            />
            {!isClean && (
              <Button
                variant="contained"
                color="primary"
                className={classes.saveButton}
                type="submit"
                onClick={() => {
                  setIsClean(false);
                  setModalDisplay(false);
                }}
                style={{
                  marginLeft: "25px",
                  maxWidth: "200px",
                  maxHeight: "100px",
                  minWidth: "200px",
                  minHeight: "20px",
                }}
              >
                Clean Data
              </Button>
            )}
            {!isClean && (
              <Button
                variant="contained"
                color="primary"
                className={classes.saveButton}
                type="submit"
                onClick={handleReset}
                style={{
                  marginLeft: "25px",
                  maxWidth: "200px",
                  maxHeight: "100px",
                  minWidth: "200px",
                  minHeight: "20px",
                }}
              >
                Reset
              </Button>
            )}
          </div>
        )}
      </FullScreenDialog>
    </>
  );
};

export default CSVUploadForm;
