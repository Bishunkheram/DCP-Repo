/* eslint-disable react/jsx-props-no-spreading */
import React, { useState } from "react";
import { withRouter } from "react-router-dom";
import PropTypes from "prop-types";
// Layout
import Layout from "../../layouts/index";
// Components
import PDFUploadForm from "./PDFUploadForm/index";
import CSVUploadForm from "./CSVUploadForm/index";
import TabsComponent from "../../components/Tabs";
import { RoleDialog } from "../../components/RoleDialog";

const propTypes = {
  location: PropTypes.shape({
    pathname: PropTypes.string,
    search: PropTypes.string,
  }).isRequired,
  history: PropTypes.shape({ push: PropTypes.func }).isRequired,
};

const HomePage = (props) => {
  const pageName = "Home";
  const [roleModal, setRoleModal] = useState(false);

  const { location, history } = props;

  const handleRoleSelectionModal = () => {
    setRoleModal(true);
  };

  const handleCloseRoleModal = () => {
    setRoleModal(false);
  };

  const tabList = [
    {
      title: "PDF UPLOAD",
      component: (
        <PDFUploadForm
          {...props}
          openRoleSelectionModal={handleRoleSelectionModal}
        />
      ),
      disabled: false,
    },
    {
      title: "EXCEL UPLOAD",
      component: (
        <CSVUploadForm
          {...props}
          openRoleSelectionModal={handleRoleSelectionModal}
        />
      ),
      disabled: false,
    },
  ];

  return (
    <Layout page={pageName} location={location} history={history}>
      <RoleDialog
        open={roleModal}
        title={"Select Role"}
        handleClose={handleCloseRoleModal}
      />
      <TabsComponent tabList={tabList} />
    </Layout>
  );
};

HomePage.propTypes = propTypes;
export default withRouter(HomePage);
