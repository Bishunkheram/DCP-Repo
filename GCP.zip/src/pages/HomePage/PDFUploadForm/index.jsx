import React, { useState } from "react";
import axios from "axios";
import { makeStyles } from "@material-ui/core/styles";
import TextField from "@material-ui/core/TextField";
import Select from "@material-ui/core/Select";
import InputLabel from "@material-ui/core/InputLabel";
import FormControl from "@material-ui/core/FormControl";
import Grid from "@material-ui/core/Grid";
import FileUpload from "../../../components/FileUpload";
import MenuItem from "@material-ui/core/MenuItem";
import "./PDFUploadForm.css";
import useWindowDimensions from "../../../hooks/useWindowDimensions";
import { SUPPORTED_FILE_TYPES } from "../../../utils";
import Button from "@material-ui/core/Button";

const useStyles = makeStyles((theme) => ({
  root: {
    display: "flex",
    alignItems: "center",
    flexWrap: "wrap",
    "& .MuiSelect-icon": {
      width: "24px !important",
      height: "24px !important",
    },
    "& .MuiOutlinedInput-input": {
      padding: "12px",
    },
    "& .MuiInputLabel-outlined": {
      transform: "translate(14px, 14px) scale(1)",
    },
    "& .MuiInputLabel-outlined.MuiInputLabel-shrink": {
      transform: "translate(10px, -10px) scale(0.75)",
    },
    "& .MuiInputBase-input.Mui-disabled": {
      backgroundColor: "blue",
    },
  },
  formControl: {
    marginTop: theme.spacing(1),
    marginBottom: theme.spacing(0.5),
    width: "100%",
  },
  textField: {
    width: "100%",
  },
  saveButton: {
    minWidth: "94px",
  },
}));

const validURL = (url) => {
  const pattern = new RegExp(
    "((http|https)://)(www.)?" +
      "[a-zA-Z0-9@:%._\\+~#?&//=]" +
      "{2,256}\\.[a-z]" +
      "{2,6}\\b([-a-zA-Z0-9@:%" +
      "._\\+~#?&//=]*)"
  );
  return pattern.test(url);
};

const PDFUploadForm = ({ openRoleSelectionModal }) => {
  const standAloneDocuments = [
    { id: 1, display: "Yes", value: "Yes" },
    { id: 2, display: "No", value: "No" },
    { id: 3, display: "Report not available", value: "Report not available" },
  ];

  const classes = useStyles();
  const [files, setFiles] = useState([]);
  const [bvd9Trigger, setbvd9Trigger] = useState(false);
  const [standAloneTrigger, setstandAloneTrigger] = useState(false);
  const [state, setState] = useState({
    company_name: "",
    id: Date.now(),
    bvd9: "",
    documentSource: "",
    documentName: "",
    categoryOfDocument: "",
    comments: "",
    publishedDate: "",
    documentUrl: "",
    urlpdf: "",
    standaloneDocument: "",
    dropZoneSelect: "",
    veid: "",
  });

  const {
    bvd9,
    company_name,
    veid,
    documentSource,
    documentName,
    categoryOfDocument,
    comments,
    publishedDate,
    documentUrl,
    urlpdf,
    standaloneDocument,
  } = state;

  const [errors, setErrors] = useState({
    company_name: "",
    bvd9: "",
    documentSource: "",
    documentName: "",
    categoryOfDocument: "",
    comments: "",
    publishedDate: "",
    documentUrl: "",
    urlpdf: "",
    standaloneDocument: "",
    veid: "",
  });

  const { isMobile } = useWindowDimensions();
  const FILE_LIMIT = 5;

  const isValid =
    bvd9.length === 9 &&
    veid.length &&
    company_name.length &&
    standaloneDocument.length &&
    categoryOfDocument.length &&
    files.length;

  const handleChange = async (e) => {
    e.preventDefault();
    const { name, value } = e.target;
    setState({
      ...state,
      [name]: value,
    });

    if (name === "bvd9") {
      const bvd9 = value;
      errors[name] = value.length !== 9 ? "bvd9 length must be 9 digits" : "";
      if (value.length === 9) {
        try {
          const response = await axios.get(
            `https://8evrd8tbzb.execute-api.us-east-1.amazonaws.com/dev/sourcedocs/?documentID=${value}`
          );
          if (response.data.errorMessage !== undefined) {
            if (response.data.errorMessage.length > 0) {
              setErrors({
                bvd9: "Incorrect BVD9ID entered",
              });
            }
          } else {
            const veid = response.data.ve_id;
            const company_name = response.data.company_name;
            setState({
              ...state,
              bvd9,
              veid,
              company_name,
            });
            setbvd9Trigger(true);
            setErrors({
              bvd9: "",
            });
          }
        } catch (error) {
          console.error(error);
        }
      } else {
        setbvd9Trigger(false);
        setState({
          ...state,
          bvd9,
          veid: "",
          company_name: "",
        });
      }
    }

    if (name === "documentUrl") {
      setState({
        ...state,
        [name]: value,
      });
      setErrors({
        ...errors,
        [name]: validURL(value) ? "" : "URL is not valid",
      });
    }

    if (name === "urlpdf") {
      setState({
        ...state,
        documentUrl: value,
        [name]: value,
      });
      setErrors({
        ...errors,
        [name]: validURL(value) ? "" : "URL is not valid",
        documentUrl: validURL(value) ? "" : "URL is not valid",
      });
    }

    if (name === "standaloneDocument") {
      const standaloneDocument = value;

      if (standaloneDocument === "Report not available") {
        setState({
          ...state,
          standaloneDocument,
          documentName: "",
          publishedDate: "",
          documentSource: "",
          documentUrl: "",
        });
        setstandAloneTrigger(true);
      } else {
        setstandAloneTrigger(false);
      }
    }
  };

  const toggleDropZone = () => {
    return state.urlpdf.length > 0;
  };

  const toggleUrlInput = () => {
    return !!state.dropZoneSelect;
  };

  const resetform = () => {
    setState({
      id: "",
      company_name: "",
      bvd9: "",
      documentSource: "",
      documentName: "",
      categoryOfDocument: "",
      comments: "",
      publishedDate: "",
      documentUrl: "",
      urlpdf: "",
      standaloneDocument: "",
      veid: "",
    });
    setErrors({
      company_name: "",
      bvd9: "",
      documentSource: "",
      documentName: "",
      categoryOfDocument: "",
      comments: "",
      publishedDate: "",
      documentUrl: "",
      urlpdf: "",
      standaloneDocument: "",
      veid: "",
    });
    setFiles([]);
  };

  const validateForm = (errors) => {
    if (errors === undefined) {
      return true;
    }
    let valid = true;
    Object.values(errors).forEach((val) => val.length > 0 && (valid = false));
    return valid;
  };

  const onSubmit = async (e) => {
    e.preventDefault();

    const role = localStorage.getItem("role");
    if (!role) {
      openRoleSelectionModal();
      return;
    }
    console.log(role);

    const valid = validateForm(state.errors);

    if (valid) {
      try {
        const { bvd9, categoryOfDocument, publishedDate } = state;
        const response = await axios.get(
          `https://ucx0mm9108.execute-api.us-east-1.amazonaws.com/pdf/upload-pdf?file=${bvd9}_
            ${categoryOfDocument}_${publishedDate}.pdf`
        );
        const file = files[0].file;
        var signedURL = response.data.URL;
        var config = {
          headers: {
            "Content-Type": file.type,
          },
        };
        await axios.put(signedURL, file, config);
      } catch (error) {}

      const {
        id,
        bvd9,
        company_name,
        veid,
        documentSource,
        documentName,
        categoryOfDocument,
        comments,
        publishedDate,
        documentUrl,
        urlpdf,
        standaloneDocument,
      } = state;

      const data = JSON.stringify({
        id: id.toString(),
        bvd9,
        company_name,
        veid,
        documentSource,
        documentName,
        categoryOfDocument,
        comments,
        publishedDate,
        documentUrl,
        urlpdf: urlpdf ? urlpdf : "NA",
        standaloneDocument,
      });

      await axios.post(
        "https://gy40fkd1p1.execute-api.us-east-1.amazonaws.com/meta/metadata",
        data
      );
      alert("Success");
      resetform();
    } else {
      alert("Invalid Form");
    }
  };

  const handleUploadUrl = () => {
    if (errors["urlpdf"]) {
      return;
    }
    try {
      const url = state.urlpdf;
      async function createFile1() {
        const blob = await fetch(url).then((r) => {
          r.blob();
        });
        const reader = new FileReader();
        reader.readAsDataURL(blob);
        reader.onloadend = () => {};
      }
      let urlpdf = state.urlpdf;
      if (urlpdf !== "") {
        createFile1();
      } else {
        urlpdf = "NA";
      }
    } catch (err) {
      setErrors({
        ...errors,
        urlpdf: "url is not an attachment",
      });
    }
  };

  const handleFileChange = (fileList, index = -1, removeFlag = false) => {
    if (removeFlag) {
      const filesArray = files;

      filesArray.splice(index, 1);

      setFiles([...filesArray]);
      setState({
        ...state,
        dropZoneSelect: false,
      });
    } else {
      if (FILE_LIMIT === 1) {
        setFiles(fileList);
      } else {
        setFiles(fileList);
        setState({
          ...state,
          dropZoneSelect: true,
        });
      }
    }
  };

  return (
    <>
      <FileUpload
        handleFileChange={handleFileChange}
        supportedFileTypes={SUPPORTED_FILE_TYPES.PDF.MIME_TYPE}
        fileLimit={FILE_LIMIT}
        fileList={files}
        click={toggleDropZone}
        disabled={!!urlpdf}
      />
      <TextField
        label="Enter URL to upload PDF"
        name="urlpdf"
        id="urlpdf"
        value={urlpdf}
        className={classes.textField}
        helperText=""
        margin="dense"
        variant="outlined"
        onChange={handleChange}
        disabled={toggleUrlInput()}
      />

      <label htmlFor="contained-button-file" onClick={handleUploadUrl}>
        <Button
          disabled={toggleUrlInput()}
          variant="contained"
          color="primary"
          component="span"
        >
          Upload
        </Button>
      </label>
      {<span>{errors.urlpdf}</span>}
      <div className={classes.root}>
        <Grid container spacing={isMobile ? 0 : 3}>
          <Grid item xs={isMobile ? 12 : 4}>
            <TextField
              required
              label="BVD9 ID"
              name="bvd9"
              id="bvd9"
              type="number"
              maxLength="9"
              value={bvd9}
              className={classes.textField}
              helperText=""
              margin="dense"
              variant="outlined"
              onChange={handleChange}
              onInput={(e) => {
                e.target.value = e.target.value.slice(0, 9);
              }}
            />
            <span>{errors.bvd9}</span>

            <TextField
              label="VE ID"
              name="veid"
              id="veid"
              value={veid}
              className={classes.textField}
              helperText=""
              margin="dense"
              variant="outlined"
              onChange={handleChange}
              disabled={bvd9Trigger}
              required
            />

            <TextField
              label="Company Name"
              name="company_name"
              id="company_name"
              value={company_name}
              className={classes.textField}
              helperText=""
              margin="dense"
              variant="outlined"
              onChange={handleChange}
              disabled={bvd9Trigger}
              required
            />

            <TextField
              label="Comments"
              name="comments"
              id="comments"
              value={comments}
              helperText=""
              margin="dense"
              variant="outlined"
              className={classes.textField}
              maxLength="2000"
              multiline={true}
              rows={5}
              onChange={handleChange}
              disabled={standAloneTrigger}
            />
          </Grid>
          <Grid item xs={isMobile ? 12 : 4}>
            <FormControl
              variant="outlined"
              required
              className={classes.formControl}
            >
              <InputLabel id="standaloneDocument-label">
                Standalone Document
              </InputLabel>
              <Select
                labelId="standaloneDocument-label"
                id="standaloneDocument"
                name="standaloneDocument"
                value={standaloneDocument}
                onChange={handleChange}
                label="standaloneDocument"
                required
              >
                {standAloneDocuments.map((sad) => (
                  <MenuItem key={sad.id} value={sad.value}>
                    {sad.display}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>

            <TextField
              label="Name Of Document"
              name="documentName"
              id="outlined-margin-dense"
              value={documentName}
              className={classes.textField}
              helperText=""
              maxLength="500"
              margin="dense"
              variant="outlined"
              onChange={handleChange}
              disabled={standAloneTrigger}
            />
            <FormControl
              variant="outlined"
              className={classes.formControl}
              onChange={handleChange}
            >
              <InputLabel id="demo-simple-select-outlined-label">
                Source of the Document
              </InputLabel>
              <Select
                labelId="demo-simple-select-outlined-label"
                id="demo-simple-select-outlined"
                name="documentSource"
                value={documentSource}
                onChange={handleChange}
                label="documentSource"
                disabled={standAloneTrigger}
              >
                <MenuItem value="Company Website">Company Website</MenuItem>
                <MenuItem value="Commercial Data Provider">
                  Commercial Data Provider
                </MenuItem>
                <MenuItem value="Public Data Source">
                  Public Data Source
                </MenuItem>
              </Select>
            </FormControl>
          </Grid>
          <Grid item xs={isMobile ? 12 : 4}>
            <FormControl
              variant="outlined"
              required
              className={classes.formControl}
            >
              <InputLabel id="categoryOfDocument-label">
                Category Of Document
              </InputLabel>
              <Select
                labelId="categoryOfDocument-label"
                name="categoryOfDocument"
                id="categoryOfDocument"
                value={categoryOfDocument}
                onChange={handleChange}
                label="categoryOfDocument"
                required
              >
                {/* <MenuItem value="">Category of Document</MenuItem> */}
                <MenuItem value="Annual Report">Annual Report </MenuItem>
                <MenuItem value="Anti-Corruption">Anti-Corruption</MenuItem>
                <MenuItem value="Code of Ethics and Business conduct">
                  Code of Ethics and Business conduct & Advertisings
                </MenuItem>
                <MenuItem value="Corporate governance report & charter">
                  Corporate governance report & charter
                </MenuItem>
                <MenuItem value="Diversity Report">Diversity Report</MenuItem>
                <MenuItem value="Environmental Technical Report">
                  Environmental Technical Report
                </MenuItem>
                <MenuItem value="Fiscal Contributions">
                  Fiscal Contributions
                </MenuItem>

                <MenuItem value="Forest Policy">Forest Policy</MenuItem>
                <MenuItem value="Health and safety">Health and safety</MenuItem>
                <MenuItem value="Human Right">Human Right</MenuItem>
                <MenuItem value="Other">Other</MenuItem>
                <MenuItem value="Sustainability Plan">
                  Sustainability Plan
                </MenuItem>
                <MenuItem value="Sustainability Report">
                  Sustainability Report
                </MenuItem>
                <MenuItem value="Technology">Technology</MenuItem>

                <MenuItem value="Whistleblower Policy">
                  Whistleblower Policy
                </MenuItem>
              </Select>
            </FormControl>

            <TextField
              label="URL for Document"
              id="documentUrl"
              name="documentUrl"
              value={documentUrl}
              className={classes.textField}
              helperText=""
              maxLength="500"
              margin="dense"
              variant="outlined"
              onChange={handleChange}
              disabled={standAloneTrigger}
            />
            {errors.documentUrl}

            <FormControl
              variant="outlined"
              margin="dense"
              className={classes.formControl}
            >
              <InputLabel id="publishedDate-label">Published Date</InputLabel>

              <Select
                labelId="publishedDate-label"
                id="publishedDate"
                name="publishedDate"
                value={publishedDate}
                onChange={handleChange}
                label="Published Date*"
                disabled={standAloneTrigger}
              >
                <MenuItem value="2016">2016</MenuItem>
                <MenuItem value="2017">2017</MenuItem>
                <MenuItem value="2018">2018</MenuItem>
                <MenuItem value="2019">2019</MenuItem>
                <MenuItem value="2020">2020</MenuItem>
                <MenuItem value="2021">2021</MenuItem>
                <MenuItem value="2022">2022</MenuItem>
                <MenuItem value="2023">2023</MenuItem>
                <MenuItem value="2024">2024</MenuItem>
                <MenuItem value="2025">2025</MenuItem>
                <MenuItem value="2026">2026</MenuItem>
                <MenuItem value="2027">2027</MenuItem>
                <MenuItem value="2028">2028</MenuItem>
                <MenuItem value="2029">2029</MenuItem>
                <MenuItem value="2030">2030</MenuItem>
              </Select>
            </FormControl>
          </Grid>
        </Grid>
        <br />
        <div className={classes.root} style={{ marginTop: "5px" }}>
          <Button
            variant="contained"
            size="large"
            color="primary"
            className={classes.margin}
            onClick={onSubmit}
            style={{
              maxWidth: "200px",
              maxHeight: "100px",
              minWidth: "200px",
              minHeight: "20px",
            }}
            // disabled={!isValid}
          >
            Submit
          </Button>

          <Button
            variant="contained"
            size="large"
            color="primary"
            className={classes.margin}
            onClick={resetform}
            style={{
              maxWidth: "200px",
              maxHeight: "100px",
              minWidth: "200px",
              minHeight: "20px",
              marginLeft: "25px",
            }}
            // onClick={this.handleResetForm}
          >
            Reset
          </Button>
        </div>
      </div>
    </>
  );
};

export default PDFUploadForm;
