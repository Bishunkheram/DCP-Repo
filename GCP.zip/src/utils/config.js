const {
  REACT_APP_OKTA_BASE_URL,
  REACT_APP_OKTA_CLIENT_ID,
  REACT_APP_OKTA_ISSUER_ID
} = process.env;

const oktaAuthConfig = {
  // Note: If your app is configured to use the Implicit Flow
  // instead of the Authorization Code with Proof of Code Key Exchange (PKCE)
  // you will need to add `pkce: false`
  issuer: REACT_APP_OKTA_ISSUER_ID,
  clientId: REACT_APP_OKTA_CLIENT_ID,
  redirectUri: `${window.location.origin}/home`,
  scopes: ['openid', 'profile', 'email'],
  onAuthRequired: true,
  scopeId: "okta.users.read",
};

const oktaSignInConfig = {
  baseUrl: REACT_APP_OKTA_BASE_URL,
  clientId: REACT_APP_OKTA_CLIENT_ID,
  redirectUri: `${window.location.origin}/home`,
  features: {
    idpDiscovery: true,
  },
  idpDiscovery: {
    requestContext: `${window.location.origin}/`,
  },
  authParams: {
    issuer: REACT_APP_OKTA_ISSUER_ID
  },
  scopes: ['openid', 'profile', 'email'],
  scopeId: "okta.users.read",
  onAuthRequired: true,
  pkce:true
};


export { oktaAuthConfig, oktaSignInConfig };
