import * as XLSX from "xlsx";
import { saveAs } from "file-saver";

const exportAsExcelFile = (json, excelFileName) => {
  // const worksheet = XLSX.utils.json_to_sheet(json);
  const ws = XLSX.utils.json_to_sheet(json);
  const csv = XLSX.utils.sheet_to_csv(ws, { FS: ";" });
  const new_csv = "\uFEFF" + csv;
  const blob = new Blob([new_csv], { type: "text/plain;charset=UTF-8" });
  saveAs(blob, `${excelFileName}.csv`);

};

export { exportAsExcelFile };
