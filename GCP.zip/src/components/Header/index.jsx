import React, { useState, useEffect } from "react";
import PropTypes from "prop-types";
import { Redirect } from "react-router-dom";

import Avatar from "@material-ui/core/Avatar";
import { deepOrange } from "@material-ui/core/colors";

import clsx from "clsx";
import { makeStyles } from "@material-ui/core/styles";
import AppBar from "@material-ui/core/AppBar";
import Toolbar from "@material-ui/core/Toolbar";
import CssBaseline from "@material-ui/core/CssBaseline";
import Typography from "@material-ui/core/Typography";
import ExitToAppIcon from "@material-ui/icons/ExitToApp";
import { useOktaAuth } from "@okta/okta-react";
import "./Header.css";

const drawerWidth = 200;

const useStyles = makeStyles((theme) => ({
  root: {
    display: "flex",
  },
  orange: {
    color: theme.palette.getContrastText(deepOrange[500]),
    backgroundColor: deepOrange[500],
    fontSize: "2rem",
  },
  appBar: {
    zIndex: theme.zIndex.drawer + 1,
    transition: theme.transitions.create(["width", "margin"], {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen,
    }),
    backgroundColor: "#2639af",
  },
  menuButton: {
    marginRight: theme.spacing(2),
  },
  hide: {
    display: "none",
  },
  title: {
    flexGrow: 1,
  },
  drawer: {
    width: drawerWidth,
    flexShrink: 0,
    whiteSpace: "nowrap",
  },
  drawerClose: {
    transition: theme.transitions.create("width", {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen,
    }),
    overflowX: "hidden",
    width: theme.spacing(7) + 1,
    [theme.breakpoints.up("sm")]: {
      width: theme.spacing(9) + 1,
    },
  },
  logOut: {
    cursor: "pointer",
  },
}));

const propTypes = {
  open: PropTypes.bool,
  page: PropTypes.string,
};

const defaultProps = {
  open: false,
  page: "",
};

const Header = ({ open, page }) => {
  const classes = useStyles();
  const { oktaAuth, authState } = useOktaAuth();
  const [userInfo, setUserInfo] = useState(null);

  const handleLogOut = async () => {
    // await oktaAuth.tokenManager.clear();
    await oktaAuth.signOut();
    localStorage.clear();
    return <Redirect to="/login" />;
  };

  useEffect(() => {
    let mounted = true;
    async function getUser() {
      const user = await oktaAuth.getUser();
      if (mounted) {
        setUserInfo(user);
      }
    }

    if (authState.isAuthenticated) {
      getUser();
    }

    return function cleanup() {
      mounted = false;
    };
  }, [authState.isAuthenticated, oktaAuth]);

  return (
    <div className={classes.root}>
      <CssBaseline />
      <AppBar
        position="fixed"
        className={clsx(classes.appBar, {
          [classes.appBarShift]: open,
        })}
      >
        <Toolbar>
          <Typography variant="h4" className={classes.title}>
            MOODY'S
          </Typography>
          <div>
            {userInfo && (
              <div>
                <Avatar className={classes.orange}>
                  {/* {userInfo.firstName.slice(0, 1).toUpperCase()}
                  {userInfo.lastName.slice(0, 1).toUpperCase()} */}
                </Avatar>
              </div>
            )}
          </div>
          {page !== "Login" && (
            <a
              href="login"
              onClick={() => {
                handleLogOut();
              }}
            >
              <ExitToAppIcon className={classes.logOut} />
            </a>
          )}
        </Toolbar>
      </AppBar>
    </div>
  );
};

Header.defaultProps = defaultProps;
Header.propTypes = propTypes;
export default Header;
