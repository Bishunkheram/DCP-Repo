import React from "react";
import PropTypes from "prop-types";

import { makeStyles } from "@material-ui/core/styles";

import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
import TableCell from "@material-ui/core/TableCell";
import TableContainer from "@material-ui/core/TableContainer";
import TableRow from "@material-ui/core/TableRow";
import Paper from "@material-ui/core/Paper";

const propTypes = {
  selectedCompany: PropTypes.string.isRequired,
  listJsonData: PropTypes.array.isRequired,
  columns: PropTypes.array.isRequired,
};

const useStyles = makeStyles({
  table: {
    minWidth: 650,
  },
});

const DataTable = ({ selectedCompany, listJsonData, columns }) => {
  const classes = useStyles();

  return (
    <>
      {listJsonData.map(
        (file, i) =>
          file.key === selectedCompany && (
            <TableContainer
              key={`container-${file.key}-${i}`}
              component={Paper}
            >
              <Table
                className={classes.table}
                key={file.key}
                aria-label="simple table"
              >
                <TableBody key={`tbody-${file.key}`}>
                  {columns.map((lbl, j) => (
                    <TableRow key={columns[j]}>
                      <TableCell key={`head-${j}`} variant="head">
                        {columns[j]}
                      </TableCell>
                      {file.values.map((filedata, k) => (
                        <TableCell key={`${columns[j]}_${k}`}>
                          {filedata[columns[j]]}
                        </TableCell>
                      ))}
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          )
      )}
    </>
  );
};

DataTable.propTypes = propTypes;
export default DataTable;
