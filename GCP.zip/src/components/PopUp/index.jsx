/* eslint-disable react/prop-types */
import React from 'react';
import './Popup.css';

const PopUp = ({ toggle }) => (
  <div className="custom-modal">
    <div className="custom-modal-content">
      <span className="close" onClick={toggle}>
        &times;
      </span>
      <h3>Filters!</h3>
    </div>
  </div>
);

export default PopUp;
