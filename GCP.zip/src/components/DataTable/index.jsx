import React from "react";
import PropTypes from "prop-types";
import { makeStyles } from "@material-ui/core/styles";
import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
import TableCell from "@material-ui/core/TableCell";
import TableContainer from "@material-ui/core/TableContainer";
import TableHead from "@material-ui/core/TableHead";
import TableRow from "@material-ui/core/TableRow";
import Paper from "@material-ui/core/Paper";

const useStyles = makeStyles({
  table: {
    minWidth: 700,
    marginTop: "20px",
  },
  root: {
    width: "100%",
  },
  container: {
    maxHeight: 440,
  },
});

const propTypes = {
  tableHeaders: PropTypes.array.isRequired,
  tableRows: PropTypes.array.isRequired,
};

const DataTableComponent = ({ tableHeaders, tableRows }) => {
  const classes = useStyles();
  return (
    <TableContainer component={Paper}>
      <Table className={classes.table} aria-label="customized table">
        <TableHead>
          <TableRow>
            {tableHeaders.map((column, index) =>
              index === 0 ? (
                <TableCell key={column}>
                  <b>{column}</b>
                </TableCell>
              ) : (
                <TableCell key={column} align="right">
                  <b>{column}</b>
                </TableCell>
              )
            )}
          </TableRow>
        </TableHead>
        <TableBody>
          {tableRows.map((row, index) => (
            <TableRow key={`row-${index}`}>
              {tableHeaders.map((column, colIndex) =>
                colIndex === 0 ? (
                  <TableCell
                    key={`cell-${colIndex}-${index}`}
                    component="th"
                    scope="row"
                  >
                    {row[column]}
                  </TableCell>
                ) : (
                  <TableCell key={`cell-${colIndex}-${index}`} align="right">
                    {row[column]}
                  </TableCell>
                )
              )}
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  );
};

DataTableComponent.propTypes = propTypes;
export default DataTableComponent;
