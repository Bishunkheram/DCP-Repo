import React from "react";
import PropTypes from "prop-types";
import { DropzoneAreaBase } from "material-ui-dropzone";
import { SUPPORTED_FILE_TYPES } from "../../utils";
import FilePreview from "./FilePreview";
import '../FileUpload/FileUpload.css';

const propTypes = {
  supportedFileTypes: PropTypes.array,
  fileLimit: PropTypes.number,
  handleFileChange: PropTypes.func.isRequired,
  showAlerts: PropTypes.bool,
  disabled: PropTypes.bool
};

const defaultProps = {
  supportedFileTypes: SUPPORTED_FILE_TYPES.ALL.MIME_TYPE,
  fileLimit: 1,
  fileList: PropTypes.array.isRequired,
  showAlerts: true,
  disabled: false
};

const FileUpload = ({
  supportedFileTypes,
  handleFileChange,
  fileLimit,
  fileList,
  showAlerts,
  disabled
}) => {
  return (
    <>
      <DropzoneAreaBase
        acceptedFiles={supportedFileTypes}
        filesLimit={fileLimit}
        dropzoneProps = {{disabled}}
        maxFileSize={90000000}
        onAdd={(files) => {
  //        console.log('--------files on dropzone onAdd', files)
          return handleFileChange(files)}
        }
        showAlerts={showAlerts}
        // onClick={disable}
        dropzoneClass="drop-zone-area"
      />

      <FilePreview fileList={fileList} handleRemove={handleFileChange} />
    </>
  );
};

FileUpload.defaultProps = defaultProps;
FileUpload.propTypes = propTypes;
export default FileUpload;
