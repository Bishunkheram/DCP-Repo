import React, { useState } from "react";
import { withStyles } from "@material-ui/core/styles";
import Button from "@material-ui/core/Button";
import FormControl from "@material-ui/core/FormControl";
import Dialog from "@material-ui/core/Dialog";
import Select from "@material-ui/core/Select";
import InputLabel from "@material-ui/core/InputLabel";
import { MenuItem } from "@material-ui/core";
import MuiDialogTitle from "@material-ui/core/DialogTitle";
import MuiDialogContent from "@material-ui/core/DialogContent";
import MuiDialogActions from "@material-ui/core/DialogActions";
import IconButton from "@material-ui/core/IconButton";
import CloseIcon from "@material-ui/icons/Close";
import Typography from "@material-ui/core/Typography";

const styles = (theme) => ({
  root: {
    margin: 0,
    padding: theme.spacing(2),
  },
  closeButton: {
    position: "absolute",
    right: theme.spacing(1),
    top: theme.spacing(1),
    color: theme.palette.grey[500],
  },
});

const DialogTitle = withStyles(styles)((props) => {
  const { children, classes, onClose, ...other } = props;
  return (
    <MuiDialogTitle disableTypography className={classes.root} {...other}>
      <Typography variant="h6">{children}</Typography>
      {onClose ? (
        <IconButton
          aria-label="close"
          className={classes.closeButton}
          onClick={onClose}
        >
          <CloseIcon />
        </IconButton>
      ) : null}
    </MuiDialogTitle>
  );
});

const DialogContent = withStyles((theme) => ({
  root: {
    padding: theme.spacing(2),
  },
}))(MuiDialogContent);

const RoleDialog = ({ handleClose, open, title }) => {
  const [role, setRole] = useState(localStorage.getItem("role") || "qa");

  const roleList = [
    { id: 1, role: "qa" },
    { id: 2, role: "dev" },
  ];
  const handleRoleChange = (e) => {
    setRole(e.target.value);
  };

  const handleSubmitForm = (e) => {
    e.preventDefault();
    localStorage.setItem("role", role);
    handleClose();
  };

  return (
    <Dialog
      onClose={handleClose}
      aria-labelledby="customized-dialog-title"
      open={open}
    >
      <DialogTitle id="customized-dialog-title" onClose={handleClose}>
        {title}
      </DialogTitle>
      <DialogContent dividers>
        <form onSubmit={handleSubmitForm}>
          <div>
            <FormControl variant="outlined" required>
              {/* className={classes.formControl} */}
              <InputLabel id="demo-simple-select-outlined-label">
                Role
              </InputLabel>
              <Select
                labelId="demo-simple-select-outlined-label"
                id="demo-simple-select-outlined"
                value={role}
                onChange={handleRoleChange}
                label="templateName"
              >
                {roleList.map((e) => (
                  <MenuItem key={e.id} value={e.role}>
                    {e.role}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
            {/* <div className={classes.root} style={{ marginTop: "5px" }}> */}
            <div style={{ marginTop: "5px" }}>
              <Button
                variant="contained"
                color="primary"
                type="submit"
                size="large"
                // className={classes.saveButton}
                style={{
                  maxWidth: "200px",
                  maxHeight: "100px",
                  minWidth: "200px",
                  minHeight: "20px",
                }}
              >
                SAVE
              </Button>
            </div>
            <br />
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export { RoleDialog };
