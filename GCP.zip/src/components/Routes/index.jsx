/* eslint-disable react/jsx-props-no-spreading */
import React from "react";
import { Route, useHistory, Switch } from "react-router-dom";
import { Security, SecureRoute, LoginCallback } from "@okta/okta-react";
import { OktaAuth } from "@okta/okta-auth-js";
import HomePage from "../../pages/HomePage";
import Discover from "../../pages/Discover";
import { oktaAuthConfig, oktaSignInConfig } from "../../utils/newConfig";
import SignInForm from "../../pages/SignInForm";
// import Login from "../../pages/Login";
import Visualize from "../../pages/Visualize";
import Protected from "../../pages/Protected";

const oktaAuthClient = new OktaAuth(oktaAuthConfig);

const AppWithRouterAccess = () => {
  const history = useHistory();

  const customAuthHandler = () => {
    history.push("/login");
  };

  return (
    <Security onAuthRequired={customAuthHandler} oktaAuth={oktaAuthClient}>
      <Switch>
        <Route
          exact
          path="/"
          render={() => <SignInForm />}
          // render={() => <Login config={oktaSignInConfig} />}
        />
        <Route
          exact
          path="/login"
          render={() => <SignInForm />}
          // render={() => <Login config={oktaSignInConfig} />}
        />
        <SecureRoute path="/protected" component={Protected} />
        <SecureRoute
          exact
          path="/home"
          render={(props) => <HomePage {...props} />}
        />
        <SecureRoute
          exact
          path="/discover"
          render={(props) => <Discover {...props} />}
        />
        <SecureRoute
          exact
          path="/visualize"
          render={(props) => <Visualize {...props} />}
        />
        <Route path="/login/callback" component={LoginCallback} />
      </Switch>
    </Security>
  );
};
export default AppWithRouterAccess;
