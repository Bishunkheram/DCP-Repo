import React from 'react';
import PropTypes from 'prop-types';

const propTypes = {
  reloadPage: PropTypes.func.isRequired,
};

const defaultProps = {};

const ActionButton = ({ reloadPage }) => (
  <div className="collapse navbar-collapse" id="myNavbar">
    <ul className="nav navbar-nav navbar-right right-side">
      <li onClick={reloadPage}>
        <a>New</a>
      </li>
      <li>
        <a href="#">Save</a>
      </li>
      <li>
        <a href="#">Open</a>
      </li>
      <li>
        <a href="#">Share</a>
      </li>
      <li>
        <a href="#">
          <i style={{ color: '#000' }} className="fa fa-refresh" />
          &nbsp; Auto-refresh
        </a>
      </li>
    </ul>
  </div>
);

ActionButton.propTypes = propTypes;
ActionButton.defaultProps = defaultProps;
export default ActionButton;
