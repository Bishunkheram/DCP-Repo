import React from 'react';
import PropTypes from 'prop-types';

const propTypes = {
  togglePop: PropTypes.func.isRequired,
};

const defaultProps = {};
const AddFilter = ({ togglePop }) => (
  <div className="panel panel-default filter-pannel">
    <div className="panel-body filter-body">
      <div className="filter-title filter-dropdown">
        Add a filter
        <span className="glyphicon glyphicon-plus add-icon" onClick={togglePop} />
      </div>
    </div>
  </div>
);

AddFilter.propTypes = propTypes;
AddFilter.defaultProps = defaultProps;
export default AddFilter;
