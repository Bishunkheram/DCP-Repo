const SUPPORTED_FILE_TYPES = {
  IMAGES: { MIME_TYPE: ["image/*"] },
  AUDIO: { MIME_TYPE: ["audio/*"] },
  VIDEO: { MIME_TYPE: ["video/*"] },
  PDF: { MIME_TYPE: ["application/pdf"] },
  ALL: { MIME_TYPE: ["*/*"] },
  WORD: {
    MIME_TYPE: [
      "application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    ],
  },
  EXCEL: {
    MIME_TYPE: [
      "application/vnd.ms-excel, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    ],
  },
  DOCS: {
    MIME_TYPE: [
      "application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document, application/vnd.ms-excel, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet ",
    ],
  },
};

module.exports = {
  SUPPORTED_FILE_TYPES,
};
