import * as FileSaver from "file-saver";
import * as XLSX from "xlsx";
import { saveAs } from "file-saver";

const EXCEL_TYPE =
  "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8";
const EXCEL_EXTENSION = ".xlsx";

const saveAsExcelFile = (buffer, fileName) => {
  const data = new Blob([buffer], {
    type: EXCEL_TYPE,
  });
  FileSaver.saveAs(
    data,
    fileName + "_export_" + new Date().getTime() + EXCEL_EXTENSION
  );
};

const exportAsExcelFile = (json, excelFileName) => {
  // const worksheet = XLSX.utils.json_to_sheet(json);
  const ws = XLSX.utils.json_to_sheet(json);
  const csv = XLSX.utils.sheet_to_csv(ws, { FS: ";" });
  const new_csv = "\uFEFF" + csv;
  const blob = new Blob([new_csv], { type: "text/plain;charset=UTF-8" });
  saveAs(blob, `${excelFileName}.csv`);

  // const workbook = {
  //   Sheets: { data: worksheet },
  //   SheetNames: ["data"],
  // };
  // const excelBuffer = XLSX.write(workbook, {
  //   bookType: "xlsx",
  //   type: "buffer",
  // });
  // saveAsExcelFile(excelBuffer, excelFileName);
};

export { exportAsExcelFile };
