/* eslint-disable no-console */
/* eslint-disable no-alert */
import React from 'react';
import axios from 'axios';
import UploadFile from '../../../components/UploadFile';
import './HomePageForm.css';

const validURL = (url) => {
  const pattern = new RegExp(
    '((http|https)://)(www.)?' +
      '[a-zA-Z0-9@:%._\\+~#?&//=]' +
      '{2,256}\\.[a-z]' +
      '{2,6}\\b([-a-zA-Z0-9@:%' +
      '._\\+~#?&//=]*)',
  );
  return pattern.test(url);
};
class HomePageFormOld extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      companyName: '',
      bvdid: '',
      documentSource: '',
      documentName: '',
      sector: '',
      description: '',
      publishedDate: '',
      documentUrl: '',
      standaloneDocument: '',
      veid: '',
      files: [],
      errors: {
        companyName: '',
        bvdid: '',
        documentSource: '',
        documentName: '',
        sector: '',
        description: '',
        publishedDate: '',
        documentUrl: '',
        standaloneDocument: '',
        veid: '',
        files: [],
      },
    };
  }

  handleChange = (e) => {
    e.preventDefault();
    // console.log('----handleChange() state change-----', this.state);
    const { name, value } = e.target;
    const state = { ...this.state };
    // console.log('-----value', value);
    state[name] = value;

    const { errors } = { ...this.state };
    if (name === 'bvdid') {
      errors.bvdid = value.length !== 9 ? 'bvdid length must be 9 digits' : '';
      if (value.length === 9) {
        axios
          .get(`http://localhost:5000/home/${value}`)
          .then((response) => {
            const { veid } = response.data[0];
            const { companyName } = response.data[0];
            this.setState((prevState) => {
              const newState = { ...prevState };
              newState.veid = veid;
              newState.companyName = companyName;
              newState.errors.bvdid = '';
              return newState;
            });
          })
          .catch((err) => console.error(err));
      }
    }
    if (name === 'documentUrl') {
      errors.documentUrl = validURL(value) ? '' : 'URL is not valid';
    }
    this.setState({ errors, [name]: value });
  };

  handleSelectedFiles = (filesArr) => {
    // console.log('FilesArr----', filesArr[0].name);
    this.setState({ files: filesArr }, () => {
      console.log(this.state);
    });
  };

  handleResetForm = () => {
    const state = {
      companyName: '',
      bvdid: '',
      documentSource: '',
      documentName: '',
      sector: '',
      description: '',
      publishedDate: '',
      documentUrl: '',
      standaloneDocument: '',
      veid: '',
      files: [],
      errors: {
        companyName: '',
        bvdid: '',
        documentSource: '',
        documentName: '',
        sector: '',
        description: '',
        publishedDate: '',
        documentUrl: '',
        standaloneDocument: '',
        veid: '',
        files: [],
      },
    };
    this.setState(state);
    console.log(this.state);
  };

  validateForm = (errors) => {
    let valid = true;
    Object.values(errors).forEach((val) => {
      if (val.length > 0) {
        valid = false;
      }
    });
    return valid;
  };

  handleSubmit = (e) => {
    e.preventDefault();
    const {
      companyName,
      bvdid,
      veid,
      documentSource,
      documentName,
      publishedDate,
      sector,
      documentUrl,
      standaloneDocument,
      description,
      files,
    } = this.state;
    const formData = new FormData();
    formData.append('companyName', companyName);
    formData.append('bvdid', bvdid);
    formData.append('veid', veid);
    formData.append('documentSource', documentSource);
    formData.append('documentName', documentName);
    formData.append('publishedDate', publishedDate);
    formData.append('standaloneDocument', standaloneDocument);
    formData.append('sector', sector);
    formData.append('documentUrl', documentUrl);
    formData.append('description', description);
    formData.append('files', files);

    const { errors } = this.state;
    const valid = this.validateForm(errors);
    if (valid) {
      alert('Success');
    } else {
      alert('Invalid Form');
    }
    this.handleResetForm();
    window.location.reload(true);
    axios
      .post('http://localhost:5000/api/company', formData, {
        headers: {
          'Content-type': 'multipart/form-data',
        },
      })
      .then((response) => {
        if (response.status >= 200 && response.status < 300) {
          console.log(response.data);
        }
        this.handleResetForm();
      });

    this.state = {
      formError: false,
    };
  };

  maxlengthCheck = (e) => !(e.target.value.length > 9);

  render() {
    const {
      bvdid,
      veid,
      companyName,
      documentSource,
      documentName,
      publishedDate,
      sector,
      documentUrl,
      standaloneDocument,
      description,
    } = this.state;
    const { errors } = this.state;
    return (
      <>
        <div className="mainDiv">
          <div>
            <UploadFile onSelectFiles={this.handleSelectedFiles} />
          </div>
          <form id="create-course-form" onSubmit={this.handleSubmit}>
            <div className="row content">
              <div className="col-md-2">
                <div className="form-group">
                  <input
                    type="number"
                    className="form-control"
                    name="bvdid"
                    id="bvdid"
                    maxLength="9"
                    value={bvdid}
                    onChange={this.handleChange}
                    onInput={(e) => {
                      e.target.value = Math.max(0, parseInt(e.target.value, 10))
                        .toString()
                        .slice(0, 9);
                    }}
                    placeholder="BvD9 ID *"
                    required
                  />
                  <span>{errors.bvdid}</span>
                </div>
              </div>
              <div className="col-md-2">
                <div className="form-group">
                  <input
                    type="text"
                    className="form-control"
                    name="veid"
                    id="veid"
                    value={veid}
                    onChange={this.handleChange}
                    placeholder="VE ID"
                  />
                </div>
              </div>

              <div className="col-md-3">
                <div className="form-group">
                  <input
                    type="text"
                    className="form-control"
                    name="companyName"
                    id="companyName"
                    value={companyName}
                    onChange={this.handleChange}
                    placeholder="Company Name"
                  />
                </div>
              </div>

              <div className="col-md-3">
                <div className="form-group">
                  <select
                    name="sector"
                    className="form-control"
                    value={sector}
                    onChange={this.handleChange}
                    required
                  >
                    <option value="">Category of Document</option>
                    <option value="Automobiles">Automobiles</option>
                    <option value="Beverage">Beverage</option>
                    <option value="Electric & Gas Utilities">Electric & Gas Utilities</option>
                    <option value="Chemicals">Chemicals</option>
                  </select>
                </div>
              </div>

              <div className="col-md-2">
                <div className="form-group">
                  <input
                    type="text"
                    className="form-control"
                    name="documentName"
                    maxLength="500"
                    id="documentName"
                    value={documentName}
                    onChange={this.handleChange}
                    placeholder="Name of Document"
                    required
                  />
                </div>
              </div>

              <div className="col-md-3">
                <div className="form-group">
                  <select
                    name="documentSource"
                    className="form-control"
                    value={documentSource}
                    onChange={this.handleChange}
                    required
                  >
                    <option value="">Source of the Document</option>
                    <option value="Company Website">Company Website</option>
                    <option value="Commercial Data Provider">Commercial Data Provider</option>
                    <option value="Public Data Source">Public Data Source</option>
                  </select>
                </div>
              </div>
              <div className="col-md-3">
                <div className="form-group">
                  <select
                    name="publishedDate"
                    className="form-control"
                    value={publishedDate}
                    onChange={this.handleChange}
                  >
                    <option value="">Published Date</option>
                    <option value="2016">2016</option>
                    <option value="2017">2017</option>
                    <option value="2018">2018</option>
                    <option value="2019">2019</option>
                    <option value="2020">2020</option>
                    <option value="2021">2021</option>
                    <option value="2022">2022</option>
                    <option value="2023">2023</option>
                    <option value="2024">2024</option>
                    <option value="2025">2025</option>
                    <option value="2026">2026</option>
                    <option value="2027">2027</option>
                    <option value="2028">2028</option>
                    <option value="2029">2029</option>
                    <option value="2030">2030</option>
                  </select>
                </div>
              </div>
              <div className="col-md-3">
                <div className="form-group">
                  <input
                    type="text"
                    className="form-control"
                    name="documentUrl"
                    maxLength="500"
                    id="documentUrl"
                    value={documentUrl}
                    onChange={this.handleChange}
                    placeholder="URL for Document"
                    required
                  />
                  {errors.documentUrl.length > 0 && <span>{errors.documentUrl}</span>}
                </div>
              </div>
              <div className="col-md-3">
                <div className="form-group">
                  <select
                    name="standaloneDocument"
                    value={standaloneDocument}
                    className="form-control"
                    onChange={this.handleChange}
                  >
                    <option value="">Standalone Document</option>
                    <option value="Yes">Yes</option>
                    <option value="No">No</option>
                    <option value="Report not available">Report not available</option>
                  </select>
                </div>
              </div>
              <div className="col-md-4">
                <div className="form-group">
                  <textarea
                    className="form-control"
                    rows="3"
                    id="description"
                    name="description"
                    maxLength="2000"
                    value={description}
                    onChange={this.handleChange}
                    placeholder="Comments"
                    required
                  />
                  <p className="require">* Required fields</p>
                </div>
                <div className="text-right">
                  {/* <button type="button" type="submit" className="btn btn-primary button-width">
                    SUBMIT
                  </button> */}
                  <button type="submit" className="btn btn-primary button-width">
                    SUBMIT
                  </button>
                  <button
                    type="button"
                    className="btn btn-secondary button-width reset-button"
                    onClick={this.handleResetForm}
                  >
                    RESET
                  </button>
                </div>
              </div>
            </div>
          </form>
        </div>
      </>
    );
  }
}
export default HomePageFormOld;
