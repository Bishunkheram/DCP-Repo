import React from "react";

import { makeStyles } from "@material-ui/core/styles";
import TextField from "@material-ui/core/TextField";
import Select from "@material-ui/core/Select";
import InputLabel from "@material-ui/core/InputLabel";
import FormControl from "@material-ui/core/FormControl";
import Grid from "@material-ui/core/Grid";

import FileUpload from "../../../components/FileUpload";
import MenuItem from "@material-ui/core/MenuItem";
import "./HomePageForm.css";
import useWindowDimensions from "../../../hooks/useWindowDimensions";
import { SUPPORTED_FILE_TYPES } from "../../../utils";

const useStyles = makeStyles((theme) => ({
  root: {
    display: "flex",
    alignItems: "center",
    flexWrap: "wrap",
    "& .MuiSelect-icon": {
      width: "24px !important",
      height: "24px !important",
    },
    "& .MuiOutlinedInput-input": {
      padding: "12px",
    },
    "& .MuiInputLabel-outlined": {
      transform: "translate(14px, 14px) scale(1)",
    },
    "& .MuiInputLabel-outlined.MuiInputLabel-shrink": {
      transform: "translate(10px, -10px) scale(0.75)",
    },
  },
  formControl: {
    marginTop: theme.spacing(1),
    marginBottom: theme.spacing(0.5),
    width: "100%",
  },
  textField: {
    width: "100%",
  },
}));

const HomePageForm = () => {
  const classes = useStyles();
  const [files, setFiles] = React.useState([]);
  const [age, setAge] = React.useState("");
  const { isMobile } = useWindowDimensions();
  const FILE_LIMIT = 5;

  const handleChange = (event) => {
    setAge(event.target.value);
  };

  function handleFileChange(fileList) {
    setFiles((files) => [...files, fileList]);
  }

  console.log("FILES:::", files);
  return (
    <>
      <FileUpload
        handleFileChange={handleFileChange}
        supportedFileTypes={SUPPORTED_FILE_TYPES.PDF.MIME_TYPE}
        fileLimit={FILE_LIMIT}
      />
      <div className={classes.root}>
        <Grid container spacing={isMobile ? 0 : 3}>
          <Grid item xs={isMobile ? 12 : 4}>
            <TextField
              label="BvD9 ID"
              id="outlined-margin-dense"
              defaultValue=""
              className={classes.textField}
              helperText=""
              margin="dense"
              variant="outlined"
            />

            <TextField
              label="VE ID"
              id="outlined-margin-dense"
              defaultValue=""
              className={classes.textField}
              helperText=""
              margin="dense"
              variant="outlined"
            />

            <TextField
              label="Company Name"
              id="outlined-margin-dense"
              defaultValue=""
              className={classes.textField}
              helperText=""
              margin="dense"
              variant="outlined"
            />

            <TextField
              label="Comments"
              id="outlined-margin-dense"
              defaultValue=""
              helperText=""
              margin="dense"
              variant="outlined"
              className={classes.textField}
              multiline={true}
              rows={8}
            />
          </Grid>
          <Grid item xs={isMobile ? 12 : 4}>
            <FormControl
              variant="outlined"
              required
              className={classes.formControl}
            >
              <InputLabel id="demo-simple-select-outlined-label">
                Category Of Document
              </InputLabel>
              <Select
                labelId="demo-simple-select-outlined-label"
                id="demo-simple-select-outlined"
                value={age}
                onChange={handleChange}
                label="Age"
              >
                <MenuItem value={10}>Ten</MenuItem>
                <MenuItem value={20}>Twenty</MenuItem>
                <MenuItem value={30}>Thirty</MenuItem>
              </Select>
            </FormControl>

            <TextField
              label="Name Of Document"
              id="outlined-margin-dense"
              defaultValue=""
              className={classes.textField}
              helperText=""
              margin="dense"
              variant="outlined"
            />
            <FormControl
              variant="outlined"
              required
              className={classes.formControl}
            >
              <InputLabel id="demo-simple-select-outlined-label">
                Source of the Document
              </InputLabel>
              <Select
                labelId="demo-simple-select-outlined-label"
                id="demo-simple-select-outlined"
                value={age}
                onChange={handleChange}
                label="Age"
              >
                <MenuItem value={10}>Ten</MenuItem>
                <MenuItem value={20}>Twenty</MenuItem>
                <MenuItem value={30}>Thirty</MenuItem>
              </Select>
            </FormControl>
          </Grid>
          <Grid item xs={isMobile ? 12 : 4}>
            <FormControl
              variant="outlined"
              required
              margin="dense"
              className={classes.formControl}
            >
              <InputLabel id="demo-simple-select-outlined-label">
                Published Date
              </InputLabel>
              <Select
                labelId="demo-simple-select-outlined-label"
                id="demo-simple-select-outlined"
                value={age}
                onChange={handleChange}
                label="Age"
              >
                <MenuItem value={10}>Ten</MenuItem>
                <MenuItem value={20}>Twenty</MenuItem>
                <MenuItem value={30}>Thirty</MenuItem>
              </Select>
            </FormControl>

            <TextField
              label="URL for Document"
              id="outlined-margin-dense"
              defaultValue=""
              className={classes.textField}
              helperText=""
              margin="dense"
              variant="outlined"
            />

            <FormControl
              variant="outlined"
              required
              className={classes.formControl}
            >
              <InputLabel id="demo-simple-select-outlined-label">
                Standalone Document
              </InputLabel>
              <Select
                labelId="demo-simple-select-outlined-label"
                id="demo-simple-select-outlined"
                value={age}
                onChange={handleChange}
                label="Age"
              >
                <MenuItem value={10}>Ten</MenuItem>
                <MenuItem value={20}>Twenty</MenuItem>
                <MenuItem value={30}>Thirty</MenuItem>
              </Select>
            </FormControl>
          </Grid>
        </Grid>

        <br />
      </div>
    </>
  );
};

export default HomePageForm;
