/* eslint-disable react/jsx-props-no-spreading */
import React from 'react';
import DocumentList from '../../components/DocumentList';
// import Header from '../../components/Header';
// import SideMenu from '../../components/SideMenu';
import { withRouter } from 'react-router-dom';
import PropTypes from 'prop-types';

// Layout
import Layout from '../../layouts/index';

const propTypes = {
  location: PropTypes.shape({ pathname: PropTypes.string, search: PropTypes.string }).isRequired,
  history: PropTypes.shape({ push: PropTypes.func }).isRequired,
};

const Discover = (props) => {
  const  pageName  = 'Discover';
  const { location } = props;
  return (
    <Layout page={pageName} location={location}>
    <DocumentList {...props} />
    </Layout>
   );
  };

Discover.propTypes = propTypes;
export default withRouter(Discover);

