import React from "react";
import PropTypes from "prop-types";
import { createStyles, makeStyles } from "@material-ui/core/styles";
import { ReactComponent as DeleteIconSvg } from "../../../assets/images/svgs/delete.svg";

const useStyles = makeStyles((theme) =>
  createStyles({
    chipRoot: {
      color: "rgba(0, 0, 0, 0.87)",
      border: "none",
      cursor: "default",
      height: "32px",
      display: "inline-flex",
      outline: "0",
      padding: "0",
      fontSize: "0.8125rem",
      boxSizing: "border-box",
      transition:
        "background-color 300ms cubic-bezier(0.4, 0, 0.2, 1) 0ms,box-shadow 300ms cubic-bezier(0.4, 0, 0.2, 1) 0ms",
      alignItems: "center",
      whiteSpace: "nowrap",
      borderRadius: "16px",
      verticalAlign: "middle",
      justifyContent: "center",
      textDecoration: "none",
      backgroundColor: "#e0e0e0",
    },
    previewChip: {
      minWidth: 160,
      maxWidth: 210,
    },
    chipOutlined: {
      border: "1px solid rgba(0, 0, 0, 0.23)",
      backgroundColor: "transparent",
    },
    deleteIconRoot: {
      fill: "currentColor",
      width: "1em",
      height: "1em",
      display: "inline-block",
      fontSize: "1.5rem",
      transition: "fill 200ms cubic-bezier(0.4, 0, 0.2, 1) 0ms",
      flexShrink: "0",
      userSelect: "none",
    },
    deleteIcon: {
      color: "rgba(0, 0, 0, 0.26)",
      width: "22px",
      cursor: "pointer",
      height: "22px",
      margin: "0 5px 0 -6px",
      marginRight: "5px",
    },
    chipLabel: {
      overflow: "hidden",
      whiteSpace: "nowrap",
      paddingLeft: "12px",
      paddingRight: "12px",
      textOverflow: "ellipsis",
    },
    previewContainer: {
      display: "flex",
      flexWrap: "wrap",
      boxSizing: "border-box",
    },
    previewList: {
      zIndex: "10",
      position: "relative",
      textAlign: "center",
      padding: "4px",
    },
  })
);

const propTypes = {
  fileList: PropTypes.array,
  handleRemove: PropTypes.func.isRequired,
};

const defaultProps = {
  fileList: [],
};

const FilePreview = ({ fileList, handleRemove }) => {
  //   const [files, setFiles] = useState([]);
  const classes = useStyles();

  console.log("PROPS::::", fileList);
  return (
    <>
      {fileList && fileList.length > 0 && (
        <>
          <span>Selected files</span>
          <div className={classes.previewContainer}>
            {fileList.map((fileName, index) => (
              <div key={`file-${index}`} className={classes.previewList}>
                <div
                  role="button"
                  className={[
                    classes.chipRoot,
                    classes.previewChip,
                    classes.chipOutlined,
                  ].join(" ")}
                  tabIndex="0"
                >
                  <span className={classes.chipLabel}>{fileName}</span>
                  <div
                    className={[
                      classes.deleteIconRoot,
                      classes.deleteIcon,
                    ].join(" ")}
                    onClick={handleRemove}
                  >
                    <DeleteIconSvg />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </>
      )}
    </>
  );
};

FilePreview.defaultProps = defaultProps;
FilePreview.propTypes = propTypes;
export default FilePreview;
