import React, { useState } from "react";
import PropTypes from "prop-types";
import { DropzoneAreaBase } from "material-ui-dropzone";
import { SUPPORTED_FILE_TYPES } from "../../utils";
import FilePreview from "./FilePreview";

const propTypes = {
  supportedFileTypes: PropTypes.array,
  fileLimit: PropTypes.number,
  handleFileChange: PropTypes.func.isRequired,
  checkValidFile: PropTypes.bool,
  isValidFile: PropTypes.bool,
};

const defaultProps = {
  supportedFileTypes: SUPPORTED_FILE_TYPES.ALL.MIME_TYPE,
  fileLimit: 1,
  checkValidFile: false,
  isValidFile: false,
};

const FileUpload = ({
  supportedFileTypes,
  handleFileChange,
  fileLimit,
  checkValidFile,
  isValidFile,
}) => {
  const [fileNames, setFileNames] = useState([]);
  console.log(fileLimit);

  const handleChange = (files) => {
    if (files && files.length > 0) {
      let fNames = [];
      files.map((fileObj) => fNames.push(fileObj.file.name));

      if (fileLimit === 1) {
        setFileNames(fNames);
        handleFileChange(files);
      } else {
        setFileNames((fileNames) => [...fileNames, fNames]);
        handleFileChange(files);
      }
      if (checkValidFile && isValidFile) {
        setFileNames([]);
      }
    }
  };

  const handleRemove = () => {};

  return (
    <>
      <DropzoneAreaBase
        acceptedFiles={supportedFileTypes}
        filesLimit={fileLimit}
        onAdd={(files) => handleChange(files)}
      />

      <FilePreview fileList={fileNames} handleRemove={handleRemove} />
    </>
  );
};

FileUpload.defaultProps = defaultProps;
FileUpload.propTypes = propTypes;
export default FileUpload;
