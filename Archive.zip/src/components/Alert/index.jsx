import React from "react";
import PropTypes from "prop-types";
import { makeStyles } from "@material-ui/core/styles";
import Alert from '@material-ui/lab/Alert';

const useStyles = makeStyles((theme) => ({
  root: {
    width: "100%",
    "& > * + *": {
      marginTop: theme.spacing(2),
    },
  },
}));

const propTypes = {
  type: PropTypes.string.isRequired,
  message: PropTypes.string.isRequired,
};

const AlertsComponent = ({ type, message }) => {
  const classes = useStyles();

  return (
    <div className={classes.root}>
      {type === "error" && (
        <Alert variant="outlined" severity="error">
          {message}
        </Alert>
      )}
      {type === "warning" && (
        <Alert variant="outlined" severity="warning">
          {message}
        </Alert>
      )}
      {type === "info" && (
        <Alert variant="outlined" severity="info">
          {message}
        </Alert>
      )}
      {type === "success" && (
        <Alert variant="outlined" severity="success">
          {message}
        </Alert>
      )}
    </div>
  );
};

AlertsComponent.propTypes = propTypes;
export default AlertsComponent;
