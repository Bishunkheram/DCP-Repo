const bubbleJsonData = [
  {
    sepalLength: '5.1',
    sepalWidth: '3.5',
    petalLength: '1.4',
    petalWidth: '0.2',
    species: 'MioTech',
  },
  {
    sepalLength: '4.9',
    sepalWidth: '3.0',
    species: 'MioTech',
  },
  {
    sepalLength: '4.7',
    sepalWidth: '3.2',
    species: 'MioTech',
  },
  {
    sepalLength: '4.6',
    sepalWidth: '3.1',
    species: 'MioTech',
  },
  {
    sepalLength: '5.0',
    sepalWidth: '3.6',
    species: 'MioTech',
  },
  {
    sepalLength: '5.4',
    sepalWidth: '3.9',
    species: 'MioTech',
  },
  {
    sepalLength: '7.0',
    sepalWidth: '3.2',
    species: "Moody's",
  },
  {
    sepalLength: '6.4',
    sepalWidth: '3.2',
    species: "Moody's",
  },
  {
    sepalLength: '6.9',
    sepalWidth: '3.1',
    species: "Moody's",
  },
  {
    sepalLength: '5.5',
    sepalWidth: '2.3',
    species: "Moody's",
  },
  {
    sepalLength: '6.5',
    sepalWidth: '2.8',
    species: "Moody's",
  },
  {
    sepalLength: '5.7',
    sepalWidth: '2.8',
    species: "Moody's",
  },
  {
    sepalLength: '5.8',
    sepalWidth: '2.7',
    petalLength: '5.1',
    species: 'MAA',
  },
  {
    sepalLength: '7.1',
    sepalWidth: '3.0',
    species: 'MAA',
  },
  {
    sepalLength: '6.3',
    sepalWidth: '2.9',
    species: 'MAA',
  },
  {
    sepalLength: '6.5',
    sepalWidth: '3.0',
    species: 'MAA',
  },
  {
    sepalLength: '7.6',
    sepalWidth: '3.0',
    species: 'MAA',
  },
  {
    sepalLength: '4.9',
    sepalWidth: '2.5',
    species: 'MAA',
  },
  {
    sepalLength: '7.3',
    sepalWidth: '2.9',
    species: 'MAA',
  },
  {
    sepalLength: '6.7',
    sepalWidth: '2.5',
    species: 'MAA',
  },
  {
    sepalLength: '7.2',
    sepalWidth: '3.6',
    species: 'MAA',
  },
];
export default bubbleJsonData;
